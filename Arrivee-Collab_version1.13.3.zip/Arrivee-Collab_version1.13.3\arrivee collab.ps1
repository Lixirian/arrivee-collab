﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem

# --- Instance unique : empêche d'ouvrir plusieurs fenêtres/bulles simultanées ---
# (En mode masqué l'app n'a ni croix ni entrée dans la barre des tâches : sans ce
#  verrou, relancer le lanceur empilerait des instances et donc des bulles.)
$global:AppCreatedNew = $false
$global:AppMutex = New-Object System.Threading.Mutex($true, 'ArriveeCollaborateur_SingleInstance', [ref]$global:AppCreatedNew)
if (-not $global:AppCreatedNew) {
    [System.Windows.Forms.MessageBox]::Show(
        "L'outil « Arrivée Collaborateur » est déjà en cours d'exécution.`r`n`r`nSi la fenêtre n'est pas visible, cliquez sur la bulle située sur le bord droit de votre écran principal pour la ramener.",
        "Arrivée Collaborateur",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    exit
}

# --- Barre de titre sombre Windows 10/11 ---
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class DarkTitleBar {
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
    [DllImport("uxtheme.dll", EntryPoint = "#135")]
    private static extern int SetPreferredAppMode(int mode);
    [DllImport("uxtheme.dll", EntryPoint = "#136")]
    private static extern void FlushMenuThemes();
    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
    public static extern int SetWindowTheme(IntPtr hwnd, string subAppName, string subIdList);
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SetCurrentProcessExplicitAppUserModelID(string AppID);
    [DllImport("user32.dll")]
    private static extern IntPtr FindWindowEx(IntPtr parent, IntPtr after, string className, string windowName);
    [DllImport("user32.dll")]
    private static extern bool EnumChildWindows(IntPtr hwnd, EnumChildProc callback, IntPtr lParam);
    private delegate bool EnumChildProc(IntPtr hwnd, IntPtr lParam);
    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWinEventHook(uint eventMin, uint eventMax, IntPtr hmodWinEventProc, WinEventDelegate lpfnWinEventProc, uint idProcess, uint idThread, uint dwFlags);
    [DllImport("user32.dll")]
    private static extern bool UnhookWinEvent(IntPtr hWinEventHook);
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern int GetClassName(IntPtr hWnd, System.Text.StringBuilder lpClassName, int nMaxCount);
    private delegate void WinEventDelegate(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime);
    private static WinEventDelegate _hookDelegate;
    private static IntPtr _hookHandle;
    public static void SetAppId(string appId) {
        SetCurrentProcessExplicitAppUserModelID(appId);
    }
    public static void Enable(IntPtr handle) {
        int val = 1;
        DwmSetWindowAttribute(handle, 20, ref val, 4);
    }
    public static void EnableAppDarkMode() {
        SetPreferredAppMode(1);
        FlushMenuThemes();
    }
    public static void ApplyDarkScrollbar(IntPtr handle) {
        SetWindowTheme(handle, "DarkMode_Explorer", null);
    }
    private static void ApplyDarkToWindow(IntPtr hwnd) {
        int val = 1;
        DwmSetWindowAttribute(hwnd, 20, ref val, 4);
        SetWindowTheme(hwnd, "DarkMode_Explorer", null);
        EnumChildWindows(hwnd, (child, lp) => {
            SetWindowTheme(child, "DarkMode_Explorer", null);
            return true;
        }, IntPtr.Zero);
    }
    public static void HookCalendarPopup() {
        _hookDelegate = new WinEventDelegate((hook, evType, hwnd, idObj, idChild, thread, time) => {
            var sb = new System.Text.StringBuilder(256);
            GetClassName(hwnd, sb, 256);
            string cls = sb.ToString();
            if (cls == "SysMonthCal32" || cls == "DropDown") {
                ApplyDarkToWindow(hwnd);
            }
        });
        uint pid = (uint)System.Diagnostics.Process.GetCurrentProcess().Id;
        _hookHandle = SetWinEventHook(0x0003, 0x0003, IntPtr.Zero, _hookDelegate, pid, 0, 0);
    }
}
"@
try { [DarkTitleBar]::EnableAppDarkMode() } catch {}
try { [DarkTitleBar]::SetAppId("SNCF.ArriveeCollaborateur") } catch {}
try { [DarkTitleBar]::HookCalendarPopup() } catch {}

# Détermination du bon dossier de base, que ce soit .ps1 ou .exe ou terminal ouvert ailleurs
if ([System.AppDomain]::CurrentDomain.FriendlyName -like '*.exe') {
    $baseDir = Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)
} elseif ($PSScriptRoot) {
    $baseDir = $PSScriptRoot
} else {
    $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
}

# --- Chargement de la configuration et des utilitaires (modules lib) ---
. (Join-Path $baseDir 'config.ps1')
. (Join-Path $baseDir 'lib\Common.ps1')
. (Join-Path $baseDir 'lib\State.ps1')
. (Join-Path $baseDir 'lib\Update.ps1')
. (Join-Path $baseDir 'lib\Tutorial.ps1')
. (Join-Path $baseDir 'lib\SnowPage.ps1')
. (Join-Path $baseDir 'lib\Homonymes.ps1')
. (Join-Path $baseDir 'lib\Doublons.ps1')

# Données d'exécution hors du dossier app (qui est écrasé à chaque MAJ) :
# %LOCALAPPDATA%\Arrivee-Collab pour l'état/log, ...\data pour les sorties métier.
$dataDir = Get-AppDataDir
$workDir = Get-AppWorkDir $dataDir
Initialize-AppLog (Join-Path $dataDir 'app_debug.log')
Write-AppLog "[INIT] App : $baseDir | Données : $dataDir"

# Active l'historique du presse-papiers (Win+V) s'il est désactivé : indispensable
# pour que le bouton « Copier tout » y place les deux notes. Best-effort, non bloquant.
[void](Enable-ClipboardHistory)

# Contexte global partagé (étendu par le Plan B : pastille MAJ, tutoriel).
$global:Ctx = @{
    Config          = $Config
    AppRoot         = $baseDir
    DataDir         = $dataDir
    WorkDir         = $workDir
    State           = (New-AppState (Join-Path $dataDir 'state.json'))
    UpdateAvailable = $null
}

# Migration « comme une mise à jour » (no-op si même version) : déclenchera le
# dialogue « Quoi de neuf » au Plan B. On capture la version précédente AVANT.
$global:PrevStateVersion = [string]$global:Ctx.State.Version
[void](Invoke-AppVersionMigration $global:Ctx.State $Config.Version)

# Chemins dossiers et fichiers importants
$resourcesFolder = Join-Path $baseDir "Resources"
$motDePasseFolder = Join-Path $workDir "Mot de passe"
$archiveFolder = Join-Path $workDir "Archive message"   # ancien archivage (< 1.13.3), purgé au démarrage

# --- Palette de couleurs (thème sombre style LixiSpace) ---
$cBgMain       = [Drawing.Color]::FromArgb(30, 30, 30)
$cBgSecondary  = [Drawing.Color]::FromArgb(37, 37, 38)
$cSurface      = [Drawing.Color]::FromArgb(45, 45, 48)
$cBorder       = [Drawing.Color]::FromArgb(62, 62, 66)
$cAccentViolet = [Drawing.Color]::FromArgb(155, 89, 182)
$cAccentVioletHover = [Drawing.Color]::FromArgb(142, 68, 173)
$cAccentBlue   = [Drawing.Color]::FromArgb(0, 122, 204)
$cAccentBlueHover = [Drawing.Color]::FromArgb(0, 90, 158)
$cDanger       = [Drawing.Color]::FromArgb(231, 76, 60)
$cSuccess      = [Drawing.Color]::FromArgb(39, 174, 96)
$cWarning      = [Drawing.Color]::FromArgb(243, 156, 18)
$cTextPrimary  = [Drawing.Color]::FromArgb(204, 204, 204)
$cTextSecondary= [Drawing.Color]::FromArgb(128, 128, 128)
$cWhite        = [Drawing.Color]::White
# Signalement des homonymes : rose vif, distinct du violet (actions), du bleu (.msg)
# et de l'orange (mot de passe déjà initialisé) pour être repéré au premier coup d'œil.
$cHomonyme      = [Drawing.Color]::FromArgb(232, 67, 147)
$cHomonymeHover = [Drawing.Color]::FromArgb(194, 53, 122)
# Doublon de demande (annulation) : rouge « danger » de la palette.
$cDangerHover   = [Drawing.Color]::FromArgb(192, 57, 43)

function Show-AlertDialog {
    param(
        [string]$message,
        [string]$title="IMPORTANT",
        [switch]$withCancel,
        [string]$buttonYesText="Oui",
        [string]$buttonNoText="Non"
    )
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = $title
    $dlg.Size = New-Object Drawing.Size(620, 320)
    $dlg.StartPosition = "CenterScreen"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.BackColor = $cBgMain
    $dlg.ForeColor = $cTextPrimary
    $dlg.Font = [Drawing.Font]::new("Segoe UI", 10)
    $dlgIconPath = Join-Path $baseDir "image-arrivee-collab.ico"
    if (Test-Path $dlgIconPath) { try { $dlg.Icon = New-Object Drawing.Icon($dlgIconPath) } catch {} }
    $dlg.Add_Shown({
        try {
            [DarkTitleBar]::Enable($this.Handle)
            [DarkTitleBar]::ApplyDarkScrollbar($rtbM.Handle)
        } catch {}
    })

    # Barre d'accent violette en haut
    $bar = New-Object Windows.Forms.Panel
    $bar.Dock = "Top"; $bar.Height = 3; $bar.BackColor = $cAccentViolet

    # Titre
    $lblT = New-Object Windows.Forms.Label
    $lblT.Text = $title
    $lblT.Font = [Drawing.Font]::new("Segoe UI", 15, [Drawing.FontStyle]::Bold)
    $lblT.ForeColor = $cAccentViolet
    $lblT.Location = New-Object Drawing.Point(25, 15)
    $lblT.AutoSize = $true

    # Corps du message (scrollable, dark scrollbar)
    $rtbM = New-Object Windows.Forms.RichTextBox
    $rtbM.Text = $message
    $rtbM.BackColor = $cBgMain
    $rtbM.ForeColor = $cTextPrimary
    $rtbM.Font = [Drawing.Font]::new("Segoe UI", 10)
    $rtbM.Location = New-Object Drawing.Point(25, 55)
    $rtbM.Size = New-Object Drawing.Size(555, 160)
    $rtbM.ReadOnly = $true
    $rtbM.BorderStyle = 'None'

    # Panneau boutons
    $bp = New-Object Windows.Forms.Panel
    $bp.Dock = "Bottom"; $bp.Height = 55; $bp.BackColor = $cBgSecondary

    if ($withCancel) {
        $btnY = New-Object Windows.Forms.Button
        $btnY.Text = $buttonYesText
        $btnY.DialogResult = [Windows.Forms.DialogResult]::Yes
        $btnY.Size = New-Object Drawing.Size(170, 35)
        $btnY.Location = New-Object Drawing.Point(250, 10)
        $btnY.FlatStyle = 'Flat'
        $btnY.FlatAppearance.BorderSize = 0
        $btnY.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
        $btnY.BackColor = $cAccentViolet
        $btnY.ForeColor = $cWhite
        $btnY.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
        $btnY.Cursor = [Windows.Forms.Cursors]::Hand
        $bp.Controls.Add($btnY)
        $dlg.AcceptButton = $btnY

        $btnN = New-Object Windows.Forms.Button
        $btnN.Text = $buttonNoText
        $btnN.DialogResult = [Windows.Forms.DialogResult]::No
        $btnN.Size = New-Object Drawing.Size(170, 35)
        $btnN.Location = New-Object Drawing.Point(430, 10)
        $btnN.FlatStyle = 'Flat'
        $btnN.FlatAppearance.BorderSize = 0
        $btnN.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(78, 78, 82)
        $btnN.BackColor = $cBorder
        $btnN.ForeColor = $cTextPrimary
        $btnN.Font = [Drawing.Font]::new("Segoe UI", 10)
        $btnN.Cursor = [Windows.Forms.Cursors]::Hand
        $bp.Controls.Add($btnN)
        $dlg.CancelButton = $btnN
    } else {
        $btnO = New-Object Windows.Forms.Button
        $btnO.Text = "OK"
        $btnO.DialogResult = [Windows.Forms.DialogResult]::OK
        $btnO.Size = New-Object Drawing.Size(120, 35)
        $btnO.Location = New-Object Drawing.Point([int](($dlg.ClientSize.Width - 120) / 2), 10)
        $btnO.FlatStyle = 'Flat'
        $btnO.FlatAppearance.BorderSize = 0
        $btnO.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
        $btnO.BackColor = $cAccentViolet
        $btnO.ForeColor = $cWhite
        $btnO.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
        $btnO.Cursor = [Windows.Forms.Cursors]::Hand
        $bp.Controls.Add($btnO)
        $dlg.AcceptButton = $btnO
    }

    $dlg.Controls.AddRange(@($rtbM, $lblT, $bar, $bp))
    return $dlg.ShowDialog()
}

# Vérification du dossier Resources
if (-not (Test-Path $resourcesFolder)) {
    Show-AlertDialog -message "Le dossier Resources n'a pas été trouvé dans : $baseDir`nVérifiez la présence du dossier et relancez." -title "Dossier Resources manquant"
    exit
}

# Création automatique des sous-dossiers si nécessaire
if (-not (Test-Path -LiteralPath $motDePasseFolder)) { New-Item -Path $motDePasseFolder -ItemType Directory | Out-Null }

# Hygiène des données sensibles au démarrage (aucun message n'est conservé par l'outil,
# la copie de référence est dans « Éléments envoyés » d'Outlook) :
#  - « Mot de passe » : .txt / .zip résiduels (génération abandonnée) => tout supprimer ;
#  - .msg préparés et jamais libérés (« Plus tard », Outlook resté ouvert) => supprimés
#    après 1 jour ;
#  - « Archive message » (archivage des versions < 1.13.3) => vidé puis supprimé.
$nPurgeMdp = Remove-FichiersAnciens $motDePasseFolder 0
$nPurgeMsg = Remove-FichiersAnciens $workDir 1 '*_notif.msg'
$nPurgeArch = Remove-FichiersAnciens $archiveFolder 0
if ((Test-Path -LiteralPath $archiveFolder) -and -not (Get-ChildItem -LiteralPath $archiveFolder -Force -ErrorAction SilentlyContinue)) {
    Remove-Item -LiteralPath $archiveFolder -Force -ErrorAction SilentlyContinue
}
if ($nPurgeMdp -or $nPurgeMsg -or $nPurgeArch) { Write-AppLog "[SECU] Purge au démarrage : $nPurgeMdp fichier(s) de mot de passe, $nPurgeMsg message(s) préparé(s), $nPurgeArch ancienne(s) archive(s)." }

# Chemins des images
$cheminHeader = Join-Path $resourcesFolder 'image arrivee collab.jpg'
$cheminSignature = Join-Path $resourcesFolder 'Signature.png'

# Vérification de la présence des images
$imagesManquantes = @()
if (-not (Test-Path $cheminHeader)) { $imagesManquantes += "image arrivee collab.jpg" }
if (-not (Test-Path $cheminSignature)) { $imagesManquantes += "Signature.png" }
if ($imagesManquantes.Count -gt 0) {
    $msg = "Les fichiers suivants sont manquants dans le dossier Resources:`n" + ($imagesManquantes -join "`n")
    Show-AlertDialog -message $msg -title "Fichiers manquants"
}

function Show-BeneficiaireDialog {
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = "Informations bénéficiaire"
    $dlg.Size = New-Object Drawing.Size(650, 280)
    $dlg.StartPosition = "CenterScreen"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = $cBgMain; $dlg.ForeColor = $cTextPrimary
    $dlg.Font = [Drawing.Font]::new("Segoe UI", 10)
    $dlgIconPath = Join-Path $baseDir "image-arrivee-collab.ico"
    if (Test-Path $dlgIconPath) { try { $dlg.Icon = New-Object Drawing.Icon($dlgIconPath) } catch {} }
    $dlg.Add_Shown({ try { [DarkTitleBar]::Enable($this.Handle) } catch {} })

    $bar = New-Object Windows.Forms.Panel
    $bar.Dock = "Top"; $bar.Height = 3; $bar.BackColor = $cAccentViolet

    $lblT = New-Object Windows.Forms.Label
    $lblT.Text = "Informations bénéficiaire"
    $lblT.Font = [Drawing.Font]::new("Segoe UI", 13, [Drawing.FontStyle]::Bold)
    $lblT.ForeColor = $cAccentViolet
    $lblT.Location = New-Object Drawing.Point(25, 15); $lblT.AutoSize = $true

    $lblEmailB = New-Object Windows.Forms.Label
    $lblEmailB.Text = "Adresse de messagerie du bénéficiaire :"
    $lblEmailB.Location = New-Object Drawing.Point(25, 55); $lblEmailB.AutoSize = $true
    $lblEmailB.ForeColor = $cTextSecondary

    $txtEmailB = New-Object Windows.Forms.TextBox
    $txtEmailB.Location = New-Object Drawing.Point(25, 78); $txtEmailB.Width = 585
    $txtEmailB.BackColor = $cSurface; $txtEmailB.ForeColor = $cTextPrimary
    $txtEmailB.BorderStyle = 'FixedSingle'; $txtEmailB.Font = [Drawing.Font]::new("Segoe UI", 10)

    $lblOU = New-Object Windows.Forms.Label
    $lblOU.Text = "OU (Organizational Unit) :"
    $lblOU.Location = New-Object Drawing.Point(25, 115); $lblOU.AutoSize = $true
    $lblOU.ForeColor = $cTextSecondary

    $cboOU = New-Object Windows.Forms.ComboBox
    $cboOU.Location = New-Object Drawing.Point(25, 138); $cboOU.Width = 585
    $cboOU.BackColor = $cSurface; $cboOU.ForeColor = $cTextPrimary
    $cboOU.FlatStyle = 'Flat'
    $cboOU.Font = [Drawing.Font]::new("Segoe UI", 10)
    $cboOU.DropDownStyle = 'DropDownList'
    $ouMap = [ordered]@{
        "GaresEtConnexions"        = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/GaresEtConnexions/Utilisateurs"
        "HEXAFRET"                 = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/HEXAFRET/Utilisateurs"
        "OPTIMSERVICES"            = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/OPTIMSERVICES/Utilisateurs"
        "SARESEAU"                 = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/SARESEAU/Utilisateurs"
        "SASNCF"                   = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/SASNCF/Utilisateurs"
        "SAVOYAGEURS"              = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/SAVOYAGEURS/Utilisateurs"
        "SudAzur"                  = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/SudAzur/Utilisateurs"
        "SudMobilitesTechnologies" = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/SudMobilitesTechnologies/Utilisateurs"
        "TECHNIS"                  = "COMMUN.AD.SNCF.FR/Ressources_Locales/Bureautique/SudEst/TECHNIS/Utilisateurs"
    }
    $cboOU.Items.AddRange(@($ouMap.Keys))
    $cboOU.SelectedIndex = 7

    $bp = New-Object Windows.Forms.Panel
    $bp.Dock = "Bottom"; $bp.Height = 55; $bp.BackColor = $cBgSecondary

    $btnOK = New-Object Windows.Forms.Button
    $btnOK.Text = "Valider"
    $btnOK.DialogResult = [Windows.Forms.DialogResult]::OK
    $btnOK.Size = New-Object Drawing.Size(150, 35)
    $btnOK.Location = New-Object Drawing.Point(310, 10)
    $btnOK.FlatStyle = 'Flat'
    $btnOK.FlatAppearance.BorderSize = 0
    $btnOK.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
    $btnOK.BackColor = $cAccentViolet; $btnOK.ForeColor = $cWhite
    $btnOK.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
    $btnOK.Cursor = [Windows.Forms.Cursors]::Hand
    $bp.Controls.Add($btnOK); $dlg.AcceptButton = $btnOK

    $btnCancel = New-Object Windows.Forms.Button
    $btnCancel.Text = "Passer"
    $btnCancel.DialogResult = [Windows.Forms.DialogResult]::Cancel
    $btnCancel.Size = New-Object Drawing.Size(150, 35)
    $btnCancel.Location = New-Object Drawing.Point(470, 10)
    $btnCancel.FlatStyle = 'Flat'
    $btnCancel.FlatAppearance.BorderSize = 0
    $btnCancel.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(78, 78, 82)
    $btnCancel.BackColor = $cBorder; $btnCancel.ForeColor = $cTextPrimary
    $btnCancel.Font = [Drawing.Font]::new("Segoe UI", 10)
    $btnCancel.Cursor = [Windows.Forms.Cursors]::Hand
    $bp.Controls.Add($btnCancel); $dlg.CancelButton = $btnCancel

    $dlg.Controls.AddRange(@($bar, $lblT, $lblEmailB, $txtEmailB, $lblOU, $cboOU, $bp))
    $result = $dlg.ShowDialog()
    if ($result -eq [Windows.Forms.DialogResult]::OK) {
        return @{ Email = $txtEmailB.Text.Trim(); OU = $ouMap[$cboOU.SelectedItem] }
    }
    return $null
}

# Liste des comptes homonymes trouvés dans ServiceNow : l'opérateur y désigne le CP
# communiqué dans la RITM ; les autres seront cités comme « CP trouvé » dans le mail.
# Renvoie @{ Action = 'ok'; CpDemande = '...' } | @{ Action = 'ignore' } | $null (annulé).
function Show-HomonymesDialog {
    param($Comptes, [string]$NomPrenom, [string]$CpActuel)
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = "Homonymes détectés"
    $dlg.Size = New-Object Drawing.Size(820, 430)
    $dlg.StartPosition = "CenterScreen"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = $cBgMain; $dlg.ForeColor = $cTextPrimary
    $dlg.Font = [Drawing.Font]::new("Segoe UI", 10)
    $dlgIconPath = Join-Path $baseDir "image-arrivee-collab.ico"
    if (Test-Path $dlgIconPath) { try { $dlg.Icon = New-Object Drawing.Icon($dlgIconPath) } catch {} }

    $bar = New-Object Windows.Forms.Panel
    $bar.Dock = "Top"; $bar.Height = 3; $bar.BackColor = $cHomonyme

    $lblT = New-Object Windows.Forms.Label
    $lblT.Text = "⚠  $(@($Comptes).Count) comptes « $NomPrenom » dans ServiceNow"
    $lblT.Font = [Drawing.Font]::new("Segoe UI", 13, [Drawing.FontStyle]::Bold)
    $lblT.ForeColor = $cHomonyme
    $lblT.Location = New-Object Drawing.Point(25, 15); $lblT.AutoSize = $true

    $lblI = New-Object Windows.Forms.Label
    $lblI.Text = "Sélectionnez le CP communiqué dans la RITM. Les autres seront indiqués au demandeur comme « CP trouvé »."
    $lblI.Location = New-Object Drawing.Point(25, 50); $lblI.Size = New-Object Drawing.Size(760, 22)
    $lblI.ForeColor = $cTextSecondary

    $lv = New-Object Windows.Forms.ListView
    $lv.Location = New-Object Drawing.Point(25, 80); $lv.Size = New-Object Drawing.Size(755, 225)
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.MultiSelect = $false; $lv.HideSelection = $false
    $lv.BackColor = $cSurface; $lv.ForeColor = $cTextPrimary; $lv.BorderStyle = 'None'
    $lv.HeaderStyle = 'Nonclickable'
    foreach ($col in @(@('CP', 110), @('Nom', 200), @('E-mail', 255), @('Actif', 60), @('Créé le', 120))) {
        [void]$lv.Columns.Add($col[0], $col[1])
    }
    # En-têtes sombres (le rendu système les laisserait blancs) ; lignes au rendu standard.
    $lv.OwnerDraw = $true
    $lv.Add_DrawColumnHeader({
        param($s, $e)
        $e.Graphics.FillRectangle((New-Object Drawing.SolidBrush($cBorder)), $e.Bounds)
        [Windows.Forms.TextRenderer]::DrawText($e.Graphics, $e.Header.Text, $s.Font, $e.Bounds, $cWhite,
            [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::Left)
    })
    $lv.Add_DrawItem({ param($s, $e) $e.DrawDefault = $true })
    $lv.Add_DrawSubItem({ param($s, $e) $e.DrawDefault = $true })
    foreach ($c in @($Comptes)) {
        $actif = if ([string]$c.active -eq 'true') { 'Oui' } else { 'Non' }
        $cree = ([string]$c.sys_created_on) -replace '\s.*$', ''
        $it = New-Object Windows.Forms.ListViewItem([string]$c.user_name)
        foreach ($v in @([string]$c.name, [string]$c.email, $actif, $cree)) { [void]$it.SubItems.Add($v) }
        [void]$lv.Items.Add($it)
        if ($CpActuel -and [string]$c.user_name -eq $CpActuel) { $it.Selected = $true }
    }
    $lv.Columns[4].Width = -2   # dernière colonne étirée jusqu'au bord (pas d'en-tête blanc résiduel)

    $bp = New-Object Windows.Forms.Panel
    $bp.Dock = "Bottom"; $bp.Height = 55; $bp.BackColor = $cBgSecondary

    $btnOK = New-Object Windows.Forms.Button
    $btnOK.Text = "Valider le CP demandé"
    $btnOK.Size = New-Object Drawing.Size(210, 35)
    $btnOK.Location = New-Object Drawing.Point(230, 10)
    $btnOK.FlatStyle = 'Flat'; $btnOK.FlatAppearance.BorderSize = 0
    $btnOK.FlatAppearance.MouseOverBackColor = $cHomonymeHover
    $btnOK.BackColor = $cHomonyme; $btnOK.ForeColor = $cWhite
    $btnOK.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
    $btnOK.Cursor = [Windows.Forms.Cursors]::Hand
    $btnOK.Add_Click({
        if ($lv.SelectedItems.Count -eq 0) {
            Show-AlertDialog -message "Sélectionnez dans la liste le CP communiqué dans la RITM." -title "CP demandé"
            return
        }
        $dlg.DialogResult = [Windows.Forms.DialogResult]::OK
    })
    $bp.Controls.Add($btnOK); $dlg.AcceptButton = $btnOK

    $btnIgn = New-Object Windows.Forms.Button
    $btnIgn.Text = "Pas un homonyme"
    $btnIgn.DialogResult = [Windows.Forms.DialogResult]::Ignore
    $btnIgn.Size = New-Object Drawing.Size(170, 35)
    $btnIgn.Location = New-Object Drawing.Point(450, 10)
    $btnIgn.FlatStyle = 'Flat'; $btnIgn.FlatAppearance.BorderSize = 1
    $btnIgn.FlatAppearance.BorderColor = $cBorder
    $btnIgn.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(62, 62, 66)
    $btnIgn.BackColor = $cBgSecondary; $btnIgn.ForeColor = $cTextPrimary
    $btnIgn.Font = [Drawing.Font]::new("Segoe UI", 10)
    $btnIgn.Cursor = [Windows.Forms.Cursors]::Hand
    $bp.Controls.Add($btnIgn)

    $btnCancel = New-Object Windows.Forms.Button
    $btnCancel.Text = "Annuler"
    $btnCancel.DialogResult = [Windows.Forms.DialogResult]::Cancel
    $btnCancel.Size = New-Object Drawing.Size(150, 35)
    $btnCancel.Location = New-Object Drawing.Point(630, 10)
    $btnCancel.FlatStyle = 'Flat'; $btnCancel.FlatAppearance.BorderSize = 0
    $btnCancel.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(78, 78, 82)
    $btnCancel.BackColor = $cBorder; $btnCancel.ForeColor = $cTextPrimary
    $btnCancel.Font = [Drawing.Font]::new("Segoe UI", 10)
    $btnCancel.Cursor = [Windows.Forms.Cursors]::Hand
    $bp.Controls.Add($btnCancel); $dlg.CancelButton = $btnCancel

    $dlg.Add_Shown({ try { [DarkTitleBar]::Enable($this.Handle); [DarkTitleBar]::ApplyDarkScrollbar($lv.Handle) } catch {} })
    $dlg.Controls.AddRange(@($bar, $lblT, $lblI, $lv, $bp))
    $r = $dlg.ShowDialog()
    if ($r -eq [Windows.Forms.DialogResult]::OK) { return @{ Action = 'ok'; CpDemande = $lv.SelectedItems[0].Text } }
    if ($r -eq [Windows.Forms.DialogResult]::Ignore) { return @{ Action = 'ignore' } }
    return $null
}

# Tâches d'arrivée déjà existantes pour ce bénéficiaire (autres RITM) : l'opérateur
# choisit la RITM à citer dans le mail d'annulation, avec le rappel de la balise.
# Renvoie @{ Action = 'ok'; Ritm = '...' } | @{ Action = 'ignore' } | $null (annulé).
function Show-DoublonsDialog {
    param($Taches, [string]$NomPrenom, [string]$RitmCourante, [string]$RitmActuelle)
    $dlg = New-Object Windows.Forms.Form
    $dlg.Text = "Doublon de demande"
    $dlg.Size = New-Object Drawing.Size(860, 470)
    $dlg.StartPosition = "CenterScreen"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = $cBgMain; $dlg.ForeColor = $cTextPrimary
    $dlg.Font = [Drawing.Font]::new("Segoe UI", 10)
    $dlgIconPath = Join-Path $baseDir "image-arrivee-collab.ico"
    if (Test-Path $dlgIconPath) { try { $dlg.Icon = New-Object Drawing.Icon($dlgIconPath) } catch {} }

    $bar = New-Object Windows.Forms.Panel
    $bar.Dock = "Top"; $bar.Height = 3; $bar.BackColor = $cDanger

    $lblT = New-Object Windows.Forms.Label
    $lblT.Text = "⛔  Demande déjà existante pour « $NomPrenom »"
    $lblT.Font = [Drawing.Font]::new("Segoe UI", 13, [Drawing.FontStyle]::Bold)
    $lblT.ForeColor = $cDanger
    $lblT.Location = New-Object Drawing.Point(25, 15); $lblT.AutoSize = $true

    $lblI = New-Object Windows.Forms.Label
    $lblI.Text = "Sélectionnez la RITM à citer dans le mail d'annulation (par défaut la plus récente)."
    $lblI.Location = New-Object Drawing.Point(25, 50); $lblI.Size = New-Object Drawing.Size(800, 22)
    $lblI.ForeColor = $cTextSecondary

    $lv = New-Object Windows.Forms.ListView
    $lv.Location = New-Object Drawing.Point(25, 80); $lv.Size = New-Object Drawing.Size(795, 215)
    $lv.View = 'Details'; $lv.FullRowSelect = $true; $lv.MultiSelect = $false; $lv.HideSelection = $false
    $lv.BackColor = $cSurface; $lv.ForeColor = $cTextPrimary; $lv.BorderStyle = 'None'
    $lv.HeaderStyle = 'Nonclickable'
    foreach ($col in @(@('RITM', 115), @('Tâche', 120), @('Statut', 95), @('Description', 230), @('Ouverte le', 115), @('Fermée le', 100))) {
        [void]$lv.Columns.Add($col[0], $col[1])
    }
    $lv.OwnerDraw = $true
    $lv.Add_DrawColumnHeader({
        param($s, $e)
        $e.Graphics.FillRectangle((New-Object Drawing.SolidBrush($cBorder)), $e.Bounds)
        [Windows.Forms.TextRenderer]::DrawText($e.Graphics, $e.Header.Text, $s.Font, $e.Bounds, $cWhite,
            [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::Left)
    })
    $lv.Add_DrawItem({ param($s, $e) $e.DrawDefault = $true })
    $lv.Add_DrawSubItem({ param($s, $e) $e.DrawDefault = $true })
    $choisi = $false
    foreach ($t in @($Taches)) {
        $it = New-Object Windows.Forms.ListViewItem([string]$t.Ritm)
        foreach ($v in @($t.Tache, $t.Statut, $t.Description, (([string]$t.Ouverte) -replace '\s.*$', ''), (([string]$t.Fermee) -replace '\s.*$', ''))) { [void]$it.SubItems.Add([string]$v) }
        [void]$lv.Items.Add($it)
        if (-not $choisi -and $RitmActuelle -and [string]$t.Ritm -eq $RitmActuelle) { $it.Selected = $true; $choisi = $true }
    }
    if (-not $choisi -and $lv.Items.Count -gt 0) { $lv.Items[0].Selected = $true }
    $lv.Columns[5].Width = -2

    # Rappel de la balise à poser sur la RITM traitée (action manuelle dans ServiceNow).
    $lblRappel = New-Object Windows.Forms.Label
    $lblRappel.Text = "Rappel : passez la balise de $RitmCourante à « Annulation - Doublon »."
    $lblRappel.Location = New-Object Drawing.Point(25, 305); $lblRappel.Size = New-Object Drawing.Size(795, 24)
    $lblRappel.ForeColor = $cWarning
    $lblRappel.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)

    $bp = New-Object Windows.Forms.Panel
    $bp.Dock = "Bottom"; $bp.Height = 55; $bp.BackColor = $cBgSecondary

    $btnOK = New-Object Windows.Forms.Button
    $btnOK.Text = "Valider la RITM"
    $btnOK.Size = New-Object Drawing.Size(190, 35)
    $btnOK.Location = New-Object Drawing.Point(290, 10)
    $btnOK.FlatStyle = 'Flat'; $btnOK.FlatAppearance.BorderSize = 0
    $btnOK.FlatAppearance.MouseOverBackColor = $cDangerHover
    $btnOK.BackColor = $cDanger; $btnOK.ForeColor = $cWhite
    $btnOK.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
    $btnOK.Cursor = [Windows.Forms.Cursors]::Hand
    $btnOK.Add_Click({
        if ($lv.SelectedItems.Count -eq 0) {
            Show-AlertDialog -message "Sélectionnez dans la liste la RITM à citer dans le mail." -title "RITM à citer"
            return
        }
        $dlg.DialogResult = [Windows.Forms.DialogResult]::OK
    })
    $bp.Controls.Add($btnOK); $dlg.AcceptButton = $btnOK

    $btnIgn = New-Object Windows.Forms.Button
    $btnIgn.Text = "Pas un doublon"
    $btnIgn.DialogResult = [Windows.Forms.DialogResult]::Ignore
    $btnIgn.Size = New-Object Drawing.Size(170, 35)
    $btnIgn.Location = New-Object Drawing.Point(490, 10)
    $btnIgn.FlatStyle = 'Flat'; $btnIgn.FlatAppearance.BorderSize = 1
    $btnIgn.FlatAppearance.BorderColor = $cBorder
    $btnIgn.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(62, 62, 66)
    $btnIgn.BackColor = $cBgSecondary; $btnIgn.ForeColor = $cTextPrimary
    $btnIgn.Font = [Drawing.Font]::new("Segoe UI", 10)
    $btnIgn.Cursor = [Windows.Forms.Cursors]::Hand
    $bp.Controls.Add($btnIgn)

    $btnCancel = New-Object Windows.Forms.Button
    $btnCancel.Text = "Annuler"
    $btnCancel.DialogResult = [Windows.Forms.DialogResult]::Cancel
    $btnCancel.Size = New-Object Drawing.Size(150, 35)
    $btnCancel.Location = New-Object Drawing.Point(670, 10)
    $btnCancel.FlatStyle = 'Flat'; $btnCancel.FlatAppearance.BorderSize = 0
    $btnCancel.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(78, 78, 82)
    $btnCancel.BackColor = $cBorder; $btnCancel.ForeColor = $cTextPrimary
    $btnCancel.Font = [Drawing.Font]::new("Segoe UI", 10)
    $btnCancel.Cursor = [Windows.Forms.Cursors]::Hand
    $bp.Controls.Add($btnCancel); $dlg.CancelButton = $btnCancel

    $dlg.Add_Shown({ try { [DarkTitleBar]::Enable($this.Handle); [DarkTitleBar]::ApplyDarkScrollbar($lv.Handle) } catch {} })
    $dlg.Controls.AddRange(@($bar, $lblT, $lblI, $lv, $lblRappel, $bp))
    $r = $dlg.ShowDialog()
    if ($r -eq [Windows.Forms.DialogResult]::OK) { return @{ Action = 'ok'; Ritm = $lv.SelectedItems[0].Text } }
    if ($r -eq [Windows.Forms.DialogResult]::Ignore) { return @{ Action = 'ignore' } }
    return $null
}

# Mot de passe : tirage cryptographique (New-MotDePasse, lib/Common.ps1).
function Generate-Password { return (New-MotDePasse) }
function Copy-Clipboard ($txt) { [System.Windows.Forms.Clipboard]::SetText($txt) }

# Copie du MOT DE PASSE : exclu de l'historique Win+V et du presse-papiers cloud
# (formats Windows dédiés), puis effacé au bout de 2 minutes s'il y est encore.
function Copy-MotDePasseSecurise {
    param([string]$Pw)
    $do = New-Object Windows.Forms.DataObject
    $do.SetText($Pw)
    foreach ($fmt in 'ExcludeClipboardContentFromMonitorProcessing', 'CanIncludeInClipboardHistory', 'CanUploadToCloudClipboard') {
        $do.SetData($fmt, (New-Object IO.MemoryStream(, [byte[]](0, 0, 0, 0))))
    }
    [Windows.Forms.Clipboard]::SetDataObject($do, $true)
    $t = New-Object Windows.Forms.Timer
    $t.Interval = 120000; $t.Tag = $Pw
    $t.Add_Tick({
        $this.Stop()
        try { if ([Windows.Forms.Clipboard]::ContainsText() -and [Windows.Forms.Clipboard]::GetText() -eq $this.Tag) { [Windows.Forms.Clipboard]::Clear() } } catch { }
        $this.Tag = $null; $this.Dispose()
    })
    $t.Start()
}

# Fichiers du mot de passe : nom assaini (ConvertTo-NomFichierSur), chemins littéraux.
function Creer-FichierMotDePasse ($pw, $nomPrenom) {
    $f = Join-Path $motDePasseFolder "$(ConvertTo-NomFichierSur $nomPrenom)-motdepasse.txt"
    Set-Content -LiteralPath $f -Value $pw
    return $f
}
function Creer-Zip ($txt, $nomPrenom) {
    $z = Join-Path $motDePasseFolder "$(ConvertTo-NomFichierSur $nomPrenom).zip"
    $d = Join-Path $env:TEMP ("ac_zip_" + [guid]::NewGuid().ToString('N'))
    if (Test-Path -LiteralPath $z) { Remove-Item -LiteralPath $z -Force }
    New-Item -Path $d -ItemType Directory | Out-Null
    try {
        Copy-Item -LiteralPath $txt -Destination (Join-Path $d "mot_de_passe.txt")
        [System.IO.Compression.ZipFile]::CreateFromDirectory($d, $z)
    } finally { Remove-Item -LiteralPath $d -Force -Recurse -ErrorAction SilentlyContinue }
    return $z
}
# Supprime le .txt et le .zip du mot de passe (le .msg contient déjà la pièce jointe).
function Remove-FichiersMotDePasse {
    foreach ($f in @($global:CheminFichierTxt, $global:CheminZip)) {
        if ($f -and (Test-Path -LiteralPath $f)) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
    }
    $global:CheminFichierTxt = $null
    $global:CheminZip = $null
}
function Creer-FichierMsg ($sujet, $dest, $htmlBody, $zipPath, $sortie) {
    try {
        $outlook = New-Object -ComObject Outlook.Application
        $mail = $outlook.CreateItem(0)
        $mail.Subject = $sujet
        $mail.To = $dest
        $mail.BodyFormat = 2
        if ($zipPath -and (Test-Path -LiteralPath $zipPath)) { [void]$mail.Attachments.Add($zipPath) }
        $mail.HTMLBody = $htmlBody
        $mail.SaveAs($sortie, 3)
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($mail)
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($outlook)
        [GC]::Collect()
        return $true
    } catch {
        Show-AlertDialog -message "Erreur lors de la création du message : $_" -title "Erreur"
        return $false
    }
}
# Suppression du .msg une fois libéré par Outlook (message envoyé ou fermé) : AUCUN
# message n'est conservé par l'outil (la copie de référence est dans « Éléments
# envoyés »). Script détaché qui attend la libération du fichier (1 h au plus ; au-delà,
# la purge du démarrage le supprime). Le chemin lui est passé en PARAMÈTRE (jamais
# inséré dans le code) et le script s'efface lui-même à la fin.
$script:WatcherSuppressionMsg = @'
param([string]$FileToWatch)
Start-Sleep -Seconds 5
for ($attempts = 0; $attempts -lt 1800; $attempts++) {
    try {
        $fs = [System.IO.File]::Open($FileToWatch, 'Open', 'ReadWrite', 'None'); $fs.Close(); $fs.Dispose()
        Remove-Item -LiteralPath $FileToWatch -Force
        break
    } catch {
        if (-not (Test-Path -LiteralPath $FileToWatch)) { break }
        Start-Sleep -Seconds 2
    }
}
Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
'@
function Attendre-FermetureOutlookEtSupprimer($cheminMsg) {
    $tempScriptPath = Join-Path $env:TEMP ("ac_msg_" + [guid]::NewGuid().ToString('N') + ".ps1")
    Set-Content -LiteralPath $tempScriptPath -Value $script:WatcherSuppressionMsg -Encoding UTF8
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $ps -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
        '-File', "`"$tempScriptPath`"", '-FileToWatch', "`"$cheminMsg`"")
}

function Get-CorpsMessageHTML_Preview {
    param($objet, $nomPrenom, $cheminHeader, $cheminSignature)
    # Saisies encodées : aucun balisage ne peut être injecté dans l'aperçu ni dans le mail.
    $objet = [System.Net.WebUtility]::HtmlEncode([string]$objet); $nomPrenom = [System.Net.WebUtility]::HtmlEncode([string]$nomPrenom)
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Segoe UI, Arial, sans-serif; font-size: 14px; margin: 0; padding: 0; background: #1E1E1E;
        scrollbar-base-color: #1E1E1E; scrollbar-face-color: #555; scrollbar-track-color: #252526;
        scrollbar-arrow-color: #808080; scrollbar-highlight-color: #555; scrollbar-shadow-color: #1E1E1E;
        scrollbar-3dlight-color: #252526; scrollbar-darkshadow-color: #1E1E1E; }
    .sujet-preview { background: #2D2D30; border-left: 3px solid #9B59B6; color: #9B59B6; font-size: 15px;
        font-weight: bold; padding: 10px 15px; margin: 12px 12px 0 12px; }
    hr.sujet { border: 0; border-top: 1px solid #3E3E42; margin: 0 12px; }
    .email-body { background: #fff; padding: 20px; margin: 0 12px 12px 12px; }
    .email-body h2 { color: #253A5E; margin-top: 0; }
    .email-body p { margin: 8px 0; color: #333; }
    .email-body a { color: #0066cc; text-decoration: underline; }
</style>
</head>
<body>
<div class='sujet-preview'>$objet</div>
<hr class='sujet'/>
<div class='email-body'>
<table style='width:100%'><tr>
<td style='width:140px; vertical-align:top;'><img src='file:///$cheminHeader' style='width:130px;'/></td>
<td style='vertical-align:top; padding-left:25px;'>
<h2>Arrivée d'un Agent SNCF</h2>
<p>Bonjour,</p>
<p>Vous avez été identifié comme déclarant de l'arrivée de <b>$nomPrenom</b>, nouveau collaborateur dans l'entreprise.</p>
<p>Son compte lui permettant d'accéder aux applications SNCF vient d'être créé et son mot de passe sera effectif d'ici 30mn maximum.</p>
<p><b>Merci de bien vouloir lui transmettre son mot de passe indiqué dans le fichier .zip en PJ</b> ainsi que les informations ci-après.</p>
<p>Pour répondre aux règles de sécurité SNCF, ce mot de passe devra être modifié dès que possible via le site <b>Mon-ID SNCF</b>.</p>
<p>La sécurité des mots de passe a été renforcée : les mots liés à votre contexte (nom, prénom, entité, ...) ou à l'entreprise (SNCF, train, cheminot, ...) ne sont plus acceptés pour construire un mot de passe.</p>
<p>Pour en savoir plus sur la politique de mot de passe en vigueur :</p>
<p><a href='https://sncf.sharepoint.com/sites/ADAAD/SitePages/politique-de-mot-de-passe-sncf.aspx'>https://sncf.sharepoint.com/sites/ADAAD/SitePages/politique-de-mot-de-passe-sncf.aspx</a><br />
<a href='https://sncf.sharepoint.com/sites/Mon-IDSNCF-SNCFContact/SitePages/azure-password-protection.aspx'>https://sncf.sharepoint.com/sites/Mon-IDSNCF-SNCFContact/SitePages/azure-password-protection.aspx</a></p>
<p>Il est vivement recommandé de renseigner un numéro de mobile sur le site Mon-ID SNCF pour faciliter de futures réinitialisations de mots de passe.</p>
<p>Pour en savoir plus sur l'utilisation de MON-ID : guides utilisateurs sur le <a href='https://sharepoint.com'>SharePoint</a>.</p>
<p><em>Ceci est un message automatique, merci de ne pas répondre.</em></p>
<div style='margin-top:20px; font-size:13px;'>
Cordialement,<br/>
<b>Votre Support Bureautique</b><br/>
SNCF - Solutions<br/>
DIRECTION SERVICES NUMERIQUES<br/>
<img src='file:///$cheminSignature' style='width:330px; margin-top:12px;'/>
</div>
</td></tr></table>
</div>
</body>
</html>
"@
}

function Get-CorpsMessageHTML_Final {
    param($nomPrenom, $cheminHeader, $cheminSignature)
    $nomPrenom = [System.Net.WebUtility]::HtmlEncode([string]$nomPrenom)
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Arial, sans-serif; font-size: 14px; margin: 20px; }
    h2 { color: #253A5E; margin-top:0; }
    p { margin: 8px 0; }
    a { color: #0066cc; text-decoration: underline; }
</style>
</head>
<body>
<table style='width:100%'><tr>
<td style='width:140px; vertical-align:top;'><img src='file:///$cheminHeader' style='width:130px;'/></td>
<td style='vertical-align:top; padding-left:25px;'>
<h2>Arrivée d'un Agent SNCF</h2>
<p>Bonjour,</p>
<p>Vous avez été identifié comme déclarant de l'arrivée de <b>$nomPrenom</b>, nouveau collaborateur dans l'entreprise.</p>
<p>Son compte lui permettant d'accéder aux applications SNCF vient d'être créé et son mot de passe sera effectif d'ici 30mn maximum.</p>
<p><b>Merci de bien vouloir lui transmettre son mot de passe indiqué dans le fichier .zip en PJ</b> ainsi que les informations ci-après.</p>
<p>Pour répondre aux règles de sécurité SNCF, ce mot de passe devra être modifié dès que possible via le site <b>Mon-ID SNCF</b>.</p>
<p>La sécurité des mots de passe a été renforcée : les mots liés à votre contexte (nom, prénom, entité, ...) ou à l'entreprise (SNCF, train, cheminot, ...) ne sont plus acceptés pour construire un mot de passe.</p>
<p>Pour en savoir plus sur la politique de mot de passe en vigueur :</p>
<p><a href='https://sncf.sharepoint.com/sites/ADAAD/SitePages/politique-de-mot-de-passe-sncf.aspx'>https://sncf.sharepoint.com/sites/ADAAD/SitePages/politique-de-mot-de-passe-sncf.aspx</a><br />
<a href='https://sncf.sharepoint.com/sites/Mon-IDSNCF-SNCFContact/SitePages/azure-password-protection.aspx'>https://sncf.sharepoint.com/sites/Mon-IDSNCF-SNCFContact/SitePages/azure-password-protection.aspx</a></p>
<p>Il est vivement recommandé de renseigner un numéro de mobile sur le site Mon-ID SNCF pour faciliter de futures réinitialisations de mots de passe.</p>
<p>Pour en savoir plus sur l'utilisation de MON-ID : guides utilisateurs sur le <a href='https://sharepoint.com'>SharePoint</a>.</p>
<p><em>Ceci est un message automatique, merci de ne pas répondre.</em></p>
<div style='margin-top:20px; font-size:13px;'>
Cordialement,<br/>
<b>Votre Support Bureautique</b><br/>
SNCF - Solutions<br/>
DIRECTION SERVICES NUMERIQUES<br/>
<img src='file:///$cheminSignature' style='width:330px; margin-top:12px;'/>
</div>
</td></tr></table>
</body>
</html>
"@
}

function Get-CorpsMessageHTML_DejaInit_Preview {
    param($objet, $nomPrenom, $dateInit, $cheminHeader, $cheminSignature)
    $objet = [System.Net.WebUtility]::HtmlEncode([string]$objet); $nomPrenom = [System.Net.WebUtility]::HtmlEncode([string]$nomPrenom); $dateInit = [System.Net.WebUtility]::HtmlEncode([string]$dateInit)
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Segoe UI, Arial, sans-serif; font-size: 14px; margin: 0; padding: 0; background: #1E1E1E;
        scrollbar-base-color: #1E1E1E; scrollbar-face-color: #555; scrollbar-track-color: #252526;
        scrollbar-arrow-color: #808080; scrollbar-highlight-color: #555; scrollbar-shadow-color: #1E1E1E;
        scrollbar-3dlight-color: #252526; scrollbar-darkshadow-color: #1E1E1E; }
    .sujet-preview { background: #2D2D30; border-left: 3px solid #F39C12; color: #F39C12; font-size: 15px;
        font-weight: bold; padding: 10px 15px; margin: 12px 12px 0 12px; }
    hr.sujet { border: 0; border-top: 1px solid #3E3E42; margin: 0 12px; }
    .email-body { background: #fff; padding: 20px; margin: 0 12px 12px 12px; }
    .email-body h2 { color: #253A5E; margin-top: 0; }
    .email-body p { margin: 8px 0; color: #333; }
    .email-body a { color: #0066cc; text-decoration: underline; }
</style>
</head>
<body>
<div class='sujet-preview'>$objet</div>
<hr class='sujet'/>
<div class='email-body'>
<table style='width:100%'><tr>
<td style='width:140px; vertical-align:top;'><img src='file:///$cheminHeader' style='width:130px;'/></td>
<td style='vertical-align:top; padding-left:25px;'>
<h2>Mouvement d'un Agent SNCF</h2>
<p>Bonjour,</p>
<p>Vous avez été identifié comme déclarant du mouvement de <b>$nomPrenom</b> nouveau collaborateur dans l'entreprise.</p>
<p>Après vérification, un mot de passe est déjà présent sur le compte depuis le <b>$dateInit</b>, nous n'allons donc pas initialiser celui-ci.</p>
<p>Si nécessaire, <b>$nomPrenom</b> peut le modifier via le site <a href='https://mon-id.sncf.fr'>mon-id.sncf.fr</a> et, en cas de problème, en appelant l'assistance mon compte au <b>0 980 980 321</b>.</p>
<p>Merci de votre compréhension.</p>
<div style='margin-top:20px; font-size:13px;'>
Cordialement,<br/>
<b>Votre Assistance Bureautique</b><br/>
SNCF - Solutions<br/>
DIRECTION SERVICES NUMERIQUES<br/>
<img src='file:///$cheminSignature' style='width:330px; margin-top:12px;'/>
</div>
</td></tr></table>
</div>
</body>
</html>
"@
}

function Get-CorpsMessageHTML_DejaInit_Final {
    param($nomPrenom, $dateInit, $cheminHeader, $cheminSignature)
    $nomPrenom = [System.Net.WebUtility]::HtmlEncode([string]$nomPrenom); $dateInit = [System.Net.WebUtility]::HtmlEncode([string]$dateInit)
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Arial, sans-serif; font-size: 14px; margin: 20px; }
    h2 { color: #253A5E; margin-top:0; }
    p { margin: 8px 0; }
    a { color: #0066cc; text-decoration: underline; }
</style>
</head>
<body>
<table style='width:100%'><tr>
<td style='width:140px; vertical-align:top;'><img src='file:///$cheminHeader' style='width:130px;'/></td>
<td style='vertical-align:top; padding-left:25px;'>
<h2>Mouvement d'un Agent SNCF</h2>
<p>Bonjour,</p>
<p>Vous avez été identifié comme déclarant du mouvement de <b>$nomPrenom</b> nouveau collaborateur dans l'entreprise.</p>
<p>Après vérification, un mot de passe est déjà présent sur le compte depuis le <b>$dateInit</b>, nous n'allons donc pas initialiser celui-ci.</p>
<p>Si nécessaire, <b>$nomPrenom</b> peut le modifier via le site <a href='https://mon-id.sncf.fr'>mon-id.sncf.fr</a> et, en cas de problème, en appelant l'assistance mon compte au <b>0 980 980 321</b>.</p>
<p>Merci de votre compréhension.</p>
<div style='margin-top:20px; font-size:13px;'>
Cordialement,<br/>
<b>Votre Assistance Bureautique</b><br/>
SNCF - Solutions<br/>
DIRECTION SERVICES NUMERIQUES<br/>
<img src='file:///$cheminSignature' style='width:330px; margin-top:12px;'/>
</div>
</td></tr></table>
</body>
</html>
"@
}

# Mail au demandeur quand des homonymes sont détectés (autres CP pour le même nom).
# Corps commun à l'aperçu et au mail final ; $cpTrouves = CP séparés par des virgules.
$global:UrlDepartDefinitif = 'https://sncf.service-now.com/portail?id=sncf_sc_cat_item_detail&sys_id=b702104ac345a150dde6d4c4e40131d8&sysparm_category=037441a51bcb0410043385506e4bcb15'
function Get-CorpsHomonymeContenu {
    param($nomPrenom, $cpDemande, $cpTrouves, $cheminHeader, $cheminSignature)
    $enc = { param($t) [System.Net.WebUtility]::HtmlEncode([string]$t) }
    $libTrouve = if (([string]$cpTrouves).Contains(',')) { 'CP trouvés' } else { 'CP trouvé' }
    $lien = [System.Net.WebUtility]::HtmlEncode($global:UrlDepartDefinitif)
    return @"
<table style='width:100%'><tr>
<td style='width:140px; vertical-align:top;'><img src='file:///$cheminHeader' style='width:130px;'/></td>
<td style='vertical-align:top; padding-left:25px;'>
<p>Bonjour,</p>
<p>Nous traitons actuellement la déclaration de mouvement pour <b>$(& $enc $nomPrenom)</b>.</p>
<p>Après vérification dans nos outils, nous constatons que nous avons d'autres CP pour ce bénéficiaire.</p>
<p>- CP que vous nous avez communiqué : <b>$(& $enc $cpDemande)</b><br/>
- $libTrouve : <b>$(& $enc $cpTrouves)</b></p>
<p>Pourriez-vous nous indiquer s'il s'agit d'un homonyme ou s'il s'agit d'un changement de statut ?</p>
<p>Si c'est un ancien compte, nous vous invitons à déclarer le départ définitif, en utilisant le formulaire ci-dessous :<br/>
<a href='$lien'>$lien</a></p>
<p>Vous remerciant par avance de votre retour.</p>
<div style='margin-top:20px; font-size:13px;'>
Cordialement,<br/>
<b>Votre Assistance Bureautique.</b><br/>
<img src='file:///$cheminSignature' style='width:330px; margin-top:12px;'/>
</div>
</td></tr></table>
"@
}

# Mail d'annulation quand la demande est un doublon d'une autre RITM.
function Get-CorpsDoublonContenu {
    param($ritmDoublon, $cheminHeader, $cheminSignature)
    $r = [System.Net.WebUtility]::HtmlEncode([string]$ritmDoublon)
    return @"
<table style='width:100%'><tr>
<td style='width:140px; vertical-align:top;'><img src='file:///$cheminHeader' style='width:130px;'/></td>
<td style='vertical-align:top; padding-left:25px;'>
<p>Bonjour,</p>
<p>Nous annulons votre sollicitation car vous avez déjà une demande en cours de traitement ou réalisée <b>$r</b> pour ce même besoin.</p>
<p>En vous remerciant de votre compréhension.</p>
<div style='margin-top:20px; font-size:13px;'>
Cordialement,<br/>
<b>Votre Assistance Bureautique</b><br/>
<img src='file:///$cheminSignature' style='width:330px; margin-top:12px;'/>
</div>
</td></tr></table>
"@
}

function Get-CorpsMessageHTML_Doublon_Preview {
    param($objet, $ritmDoublon, $cheminHeader, $cheminSignature)
    $contenu = Get-CorpsDoublonContenu $ritmDoublon $cheminHeader $cheminSignature
    $objetHtml = [System.Net.WebUtility]::HtmlEncode([string]$objet)
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Segoe UI, Arial, sans-serif; font-size: 14px; margin: 0; padding: 0; background: #1E1E1E;
        scrollbar-base-color: #1E1E1E; scrollbar-face-color: #555; scrollbar-track-color: #252526;
        scrollbar-arrow-color: #808080; scrollbar-highlight-color: #555; scrollbar-shadow-color: #1E1E1E;
        scrollbar-3dlight-color: #252526; scrollbar-darkshadow-color: #1E1E1E; }
    .sujet-preview { background: #2D2D30; border-left: 3px solid #E74C3C; color: #E74C3C; font-size: 15px;
        font-weight: bold; padding: 10px 15px; margin: 12px 12px 0 12px; }
    hr.sujet { border: 0; border-top: 1px solid #3E3E42; margin: 0 12px; }
    .email-body { background: #fff; padding: 20px; margin: 0 12px 12px 12px; }
    .email-body p { margin: 8px 0; color: #333; }
</style>
</head>
<body>
<div class='sujet-preview'>$objetHtml</div>
<hr class='sujet'/>
<div class='email-body'>
$contenu
</div>
</body>
</html>
"@
}

function Get-CorpsMessageHTML_Doublon_Final {
    param($ritmDoublon, $cheminHeader, $cheminSignature)
    $contenu = Get-CorpsDoublonContenu $ritmDoublon $cheminHeader $cheminSignature
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Arial, sans-serif; font-size: 14px; margin: 20px; }
    p { margin: 8px 0; }
</style>
</head>
<body>
$contenu
</body>
</html>
"@
}

function Get-CorpsMessageHTML_Homonyme_Preview {
    param($objet, $nomPrenom, $cpDemande, $cpTrouves, $cheminHeader, $cheminSignature)
    $contenu = Get-CorpsHomonymeContenu $nomPrenom $cpDemande $cpTrouves $cheminHeader $cheminSignature
    $objetHtml = [System.Net.WebUtility]::HtmlEncode([string]$objet)
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Segoe UI, Arial, sans-serif; font-size: 14px; margin: 0; padding: 0; background: #1E1E1E;
        scrollbar-base-color: #1E1E1E; scrollbar-face-color: #555; scrollbar-track-color: #252526;
        scrollbar-arrow-color: #808080; scrollbar-highlight-color: #555; scrollbar-shadow-color: #1E1E1E;
        scrollbar-3dlight-color: #252526; scrollbar-darkshadow-color: #1E1E1E; }
    .sujet-preview { background: #2D2D30; border-left: 3px solid #E84393; color: #E84393; font-size: 15px;
        font-weight: bold; padding: 10px 15px; margin: 12px 12px 0 12px; }
    hr.sujet { border: 0; border-top: 1px solid #3E3E42; margin: 0 12px; }
    .email-body { background: #fff; padding: 20px; margin: 0 12px 12px 12px; }
    .email-body p { margin: 8px 0; color: #333; }
    .email-body a { color: #0066cc; text-decoration: underline; word-break: break-all; }
</style>
</head>
<body>
<div class='sujet-preview'>$objetHtml</div>
<hr class='sujet'/>
<div class='email-body'>
$contenu
</div>
</body>
</html>
"@
}

function Get-CorpsMessageHTML_Homonyme_Final {
    param($nomPrenom, $cpDemande, $cpTrouves, $cheminHeader, $cheminSignature)
    $contenu = Get-CorpsHomonymeContenu $nomPrenom $cpDemande $cpTrouves $cheminHeader $cheminSignature
    return @"
<html>
<head>
<meta charset='UTF-8'>
<style>
    body { font-family: Arial, sans-serif; font-size: 14px; margin: 20px; }
    p { margin: 8px 0; }
    a { color: #0066cc; text-decoration: underline; }
</style>
</head>
<body>
$contenu
</body>
</html>
"@
}

# --- Interface principale (thème sombre LixiSpace) ---
$form = New-Object Windows.Forms.Form
$form.Text = "Arrivée Collaborateur"
$form.Size = New-Object Drawing.Size(1100, 920)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBgMain
$form.ForeColor = $cTextPrimary
$form.Font = [Drawing.Font]::new("Segoe UI", 10)
$form.MinimumSize = New-Object Drawing.Size(1095, 650)
# Icône personnalisée
$iconPath = Join-Path $baseDir "image-arrivee-collab.ico"
if (Test-Path $iconPath) {
    try { $form.Icon = New-Object Drawing.Icon($iconPath) } catch {}
} else {
    try { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName) } catch {}
}
$form.Add_Shown({
    try {
        [DarkTitleBar]::Enable($this.Handle)
        [DarkTitleBar]::ApplyDarkScrollbar($panelPreview.Handle)
        [DarkTitleBar]::ApplyDarkScrollbar($panelForm.Handle)
        [DarkTitleBar]::ApplyDarkScrollbar($panelActions.Handle)
        [DarkTitleBar]::ApplyDarkScrollbar($rtbCopy.Handle)
        [DarkTitleBar]::ApplyDarkScrollbar($rtbMsg.Handle)
    } catch {}
})

# --- Barre d'accent violette ---
$accentBar = New-Object Windows.Forms.Panel
$accentBar.Dock = "Top"; $accentBar.Height = 3; $accentBar.BackColor = $cAccentViolet
$form.Controls.Add($accentBar)

# --- En-tête ---
$lblTitle = New-Object Windows.Forms.Label
$lblTitle.Text = "Arrivée Collaborateur"
$lblTitle.Font = [Drawing.Font]::new("Segoe UI", 16, [Drawing.FontStyle]::Bold)
$lblTitle.ForeColor = $cWhite
$lblTitle.Location = New-Object Drawing.Point(25, 15)
$lblTitle.AutoSize = $true
$form.Controls.Add($lblTitle)

$lblSubTitle = New-Object Windows.Forms.Label
$lblSubTitle.Text = "Notification mot de passe - Arrivée collaborateur"
$lblSubTitle.Font = [Drawing.Font]::new("Segoe UI", 9)
$lblSubTitle.ForeColor = $cTextSecondary
$lblSubTitle.Location = New-Object Drawing.Point(27, 45)
$lblSubTitle.AutoSize = $true
$form.Controls.Add($lblSubTitle)

# --- Pastille de mise à jour (cachée par défaut, ancrée en haut à droite) ---
$lblUpdateBadge = New-Object Windows.Forms.Label
$lblUpdateBadge.Text = "  ⬆ Mise à jour disponible  "
$lblUpdateBadge.AutoSize = $true
$lblUpdateBadge.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$lblUpdateBadge.ForeColor = $cWhite
$lblUpdateBadge.BackColor = $cWarning
$lblUpdateBadge.Padding = New-Object Windows.Forms.Padding(6, 4, 6, 4)
$lblUpdateBadge.Location = New-Object Drawing.Point(900, 22)
$lblUpdateBadge.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$lblUpdateBadge.Cursor = [Windows.Forms.Cursors]::Hand
$lblUpdateBadge.Visible = $false
$lblUpdateBadge.Add_Click({ Invoke-PromptAndUpdate $global:Ctx })
$form.Controls.Add($lblUpdateBadge)
$lblUpdateBadge.BringToFront()
$global:Ctx.UpdateBadge = $lblUpdateBadge

# --- Bouton « ? » : rejouer le tutoriel (en-tête, ancré en haut à droite) ---
$btnHelp = New-Object Windows.Forms.Button
$btnHelp.Text = "?"
$btnHelp.Size = New-Object Drawing.Size(34, 34)
$btnHelp.Location = New-Object Drawing.Point(1042, 18)
$btnHelp.FlatStyle = 'Flat'; $btnHelp.FlatAppearance.BorderSize = 0
$btnHelp.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
$btnHelp.BackColor = $cBorder; $btnHelp.ForeColor = $cWhite
$btnHelp.Font = [Drawing.Font]::new("Segoe UI", 12, [Drawing.FontStyle]::Bold)
$btnHelp.Cursor = [Windows.Forms.Cursors]::Hand
$btnHelp.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$btnHelp.Add_Click({ try { Show-Tutorial $global:Ctx } catch { Write-AppLog "[TUTO] Relecture KO : $($_.Exception.Message)" } })
$form.Controls.Add($btnHelp)
$btnHelp.BringToFront()

# Repositionne la pastille en haut à droite quel que soit son texte (largeur auto).
function Update-UpdateBadge {
    param($Ctx)
    $b = $Ctx.UpdateBadge
    if (-not $b) { return }
    $action = {
        if ($Ctx.UpdateAvailable) {
            $b.Text = "  ⬆ Mise à jour $($Ctx.UpdateAvailable.Version)  "
            $b.Left = $btnHide.Left - $b.Width - 10
            $b.Visible = $true; $b.BringToFront()
        } else { $b.Visible = $false }
    }
    if ($form.InvokeRequired) { $form.Invoke([Action]$action) } else { & $action }
}

# --- Panneau formulaire (fond secondaire) ---
$panelForm = New-Object Windows.Forms.Panel
$panelForm.Location = New-Object Drawing.Point(20, 75)
$panelForm.Size = New-Object Drawing.Size(1045, 179)
$panelForm.BackColor = $cBgSecondary
$panelForm.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right
$form.Controls.Add($panelForm)

# Colonnes de saisie
$col1Lbl = 15; $col1In = 165; $col2Lbl = 415; $col2In = 580; $inW = 220

# Ligne 1 : RITM + Email
$lblRITM = New-Object Windows.Forms.Label
$lblRITM.Text = "RITM :"; $lblRITM.AutoSize = $true
$lblRITM.Location = New-Object Drawing.Point($col1Lbl, 18)
$lblRITM.ForeColor = $cTextSecondary
$txtRITM = New-Object Windows.Forms.TextBox
$txtRITM.Location = New-Object Drawing.Point($col1In, 15); $txtRITM.Width = $inW
$txtRITM.BackColor = $cSurface; $txtRITM.ForeColor = $cTextPrimary
$txtRITM.BorderStyle = 'FixedSingle'; $txtRITM.Font = [Drawing.Font]::new("Segoe UI", 10)

$lblEmail = New-Object Windows.Forms.Label
$lblEmail.Text = "Email du demandeur :"; $lblEmail.AutoSize = $true
$lblEmail.Location = New-Object Drawing.Point($col2Lbl, 18)
$lblEmail.ForeColor = $cTextSecondary
$txtEmail = New-Object Windows.Forms.TextBox
$txtEmail.Location = New-Object Drawing.Point($col2In, 15); $txtEmail.Width = $inW
$txtEmail.BackColor = $cSurface; $txtEmail.ForeColor = $cTextPrimary
$txtEmail.BorderStyle = 'FixedSingle'; $txtEmail.Font = [Drawing.Font]::new("Segoe UI", 10)

# Ligne 2 : Nom et prénom (champ unique, saisie « Prénom Nom »)
$lblNomPrenom = New-Object Windows.Forms.Label
$lblNomPrenom.Text = "Nom et prénom :"; $lblNomPrenom.AutoSize = $true
$lblNomPrenom.Location = New-Object Drawing.Point($col1Lbl, 58)
$lblNomPrenom.ForeColor = $cTextSecondary
$txtNomPrenom = New-Object Windows.Forms.TextBox
$txtNomPrenom.Location = New-Object Drawing.Point($col1In, 55); $txtNomPrenom.Width = $inW
$txtNomPrenom.BackColor = $cSurface; $txtNomPrenom.ForeColor = $cTextPrimary
$txtNomPrenom.BorderStyle = 'FixedSingle'; $txtNomPrenom.Font = [Drawing.Font]::new("Segoe UI", 10)

# Ligne 4 : vérifications ServiceNow (page cachée), lancées automatiquement ~1 s
# après la saisie ; chaque bouton relance la sienne.
#   colonne 1 = homonymes (nom), colonne 2 = doublons de demande (RITM + nom).
$btnVerifHomo = New-Object Windows.Forms.Button
$btnVerifHomo.Text = "Vérif. homonymes"
$btnVerifHomo.Location = New-Object Drawing.Point($col1Lbl, 131)
$btnVerifHomo.Size = New-Object Drawing.Size(140, 28)
$btnVerifHomo.FlatStyle = 'Flat'
$btnVerifHomo.FlatAppearance.BorderSize = 1
$btnVerifHomo.FlatAppearance.BorderColor = $cBorder
$btnVerifHomo.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(62, 62, 66)
$btnVerifHomo.BackColor = $cSurface; $btnVerifHomo.ForeColor = $cTextPrimary
$btnVerifHomo.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$btnVerifHomo.Cursor = [Windows.Forms.Cursors]::Hand

# État de la vérification. En cas d'homonymes : pastille rose bien visible,
# cliquable pour choisir le CP demandé.
$lblHomo = New-Object Windows.Forms.Label
$lblHomo.Location = New-Object Drawing.Point($col1In, 131)
$lblHomo.Size = New-Object Drawing.Size($inW, 28)
$lblHomo.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$lblHomo.AutoEllipsis = $true
$lblHomo.Padding = New-Object Windows.Forms.Padding(6, 0, 0, 0)
$lblHomo.Font = [Drawing.Font]::new("Segoe UI", 9)
$global:TipHomo = New-Object Windows.Forms.ToolTip

$btnVerifDoublon = New-Object Windows.Forms.Button
$btnVerifDoublon.Text = "Vérif. doublons"
$btnVerifDoublon.Location = New-Object Drawing.Point($col2Lbl, 131)
$btnVerifDoublon.Size = New-Object Drawing.Size(140, 28)
$btnVerifDoublon.FlatStyle = 'Flat'
$btnVerifDoublon.FlatAppearance.BorderSize = 1
$btnVerifDoublon.FlatAppearance.BorderColor = $cBorder
$btnVerifDoublon.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(62, 62, 66)
$btnVerifDoublon.BackColor = $cSurface; $btnVerifDoublon.ForeColor = $cTextPrimary
$btnVerifDoublon.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$btnVerifDoublon.Cursor = [Windows.Forms.Cursors]::Hand

# État des doublons. Doublon trouvé : pastille rouge cliquable (RITM à citer).
$lblDoublon = New-Object Windows.Forms.Label
$lblDoublon.Location = New-Object Drawing.Point($col2In, 131)
$lblDoublon.Size = New-Object Drawing.Size($inW, 28)
$lblDoublon.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$lblDoublon.AutoEllipsis = $true
$lblDoublon.Padding = New-Object Windows.Forms.Padding(6, 0, 0, 0)
$lblDoublon.Font = [Drawing.Font]::new("Segoe UI", 9)

# Images (droite du panneau)
$picHeader = New-Object Windows.Forms.PictureBox
$picHeader.SizeMode = 'Zoom'
$picHeader.Location = New-Object Drawing.Point(830, 10)
$picHeader.Size = New-Object Drawing.Size(90, 55)
$picHeader.BackColor = $cSurface
$picHeader.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
if (Test-Path $cheminHeader) { try { $picHeader.Image = [Drawing.Image]::FromFile($cheminHeader) } catch {} }

$picSignature = New-Object Windows.Forms.PictureBox
$picSignature.SizeMode = 'Zoom'
$picSignature.Location = New-Object Drawing.Point(930, 10)
$picSignature.Size = New-Object Drawing.Size(100, 55)
$picSignature.BackColor = $cSurface
$picSignature.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
if (Test-Path $cheminSignature) { try { $picSignature.Image = [Drawing.Image]::FromFile($cheminSignature) } catch {} }

$lblStatusImg = New-Object Windows.Forms.Label
$lblStatusImg.Location = New-Object Drawing.Point(830, 75); $lblStatusImg.Width = 200
$lblStatusImg.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$lblStatusImg.Font = [Drawing.Font]::new("Segoe UI", 8)
if ((Test-Path $cheminHeader) -and (Test-Path $cheminSignature)) {
    $lblStatusImg.Text = "Images détectées"; $lblStatusImg.ForeColor = $cSuccess
} else {
    $lblStatusImg.Text = "Vérifier les images !"; $lblStatusImg.ForeColor = $cDanger
}

# Case à cocher VISIBLE de la préférence « réduction automatique en bulle » (la même
# option que le clic droit sur « » » / sur la bulle, plus explicite). Cochée = l'app
# se replie en bulle à la perte de focus ; décochée = elle reste affichée. Synchronisée
# dans les deux sens avec les menus contextuels via Set-AutoHideDisabled.
$chkAutoBulle = New-Object Windows.Forms.CheckBox
$chkAutoBulle.Text = "  Réduction auto en bulle"
$chkAutoBulle.Location = New-Object Drawing.Point(830, 100)
$chkAutoBulle.Size = New-Object Drawing.Size(200, 28)
$chkAutoBulle.ForeColor = $cTextPrimary
$chkAutoBulle.BackColor = $cBgSecondary
$chkAutoBulle.Font = [Drawing.Font]::new("Segoe UI", 9)
$chkAutoBulle.FlatStyle = 'Flat'
# Case lisible sur fond sombre : le rendu système (gris sur gris) est redessiné
# par-dessus — contour violet décochée, remplie de violet avec coche blanche cochée.
$chkAutoBulle.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $t = 14; $y = [int](($s.ClientSize.Height - $t) / 2)
    $g.FillRectangle((New-Object Drawing.SolidBrush($cBgSecondary)), -1, ($y - 2), ($t + 3), ($t + 4))
    $box = New-Object Drawing.Rectangle(0, $y, $t, $t)
    if ($s.Checked) {
        $g.FillRectangle((New-Object Drawing.SolidBrush($cAccentViolet)), $box)
        $pen = New-Object Drawing.Pen($cWhite, 2)
        $g.DrawLines($pen, [Drawing.Point[]]@((New-Object Drawing.Point(3, ($y + 7))), (New-Object Drawing.Point(6, ($y + 10))), (New-Object Drawing.Point(11, ($y + 4)))))
        $pen.Dispose()
    } else {
        $g.FillRectangle((New-Object Drawing.SolidBrush($cSurface)), $box)
        $pen = New-Object Drawing.Pen($cAccentViolet, 1.5)
        $g.DrawRectangle($pen, 0, $y, ($t - 1), ($t - 1))
        $pen.Dispose()
    }
})
$chkAutoBulle.Cursor = [Windows.Forms.Cursors]::Hand
$chkAutoBulle.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$chkAutoBulle.Checked = -not [bool]$global:Ctx.State.AutoHideDisabled
$chkAutoBulle.Add_CheckedChanged({ Set-AutoHideDisabled (-not $chkAutoBulle.Checked) })

# Ligne 3 : Checkbox mot de passe déjà initialisé + décompte « il y a X jours »
$chkMdpDejaInit = New-Object Windows.Forms.CheckBox
$chkMdpDejaInit.Text = "  Mot de passe déjà initialisé"
$chkMdpDejaInit.Appearance = 'Button'
$chkMdpDejaInit.Location = New-Object Drawing.Point($col1Lbl, 90)
$chkMdpDejaInit.Size = New-Object Drawing.Size(250, 32)
$chkMdpDejaInit.ForeColor = $cWarning
$chkMdpDejaInit.BackColor = $cSurface
$chkMdpDejaInit.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$chkMdpDejaInit.FlatStyle = 'Flat'
$chkMdpDejaInit.FlatAppearance.BorderColor = $cWarning
$chkMdpDejaInit.FlatAppearance.BorderSize = 1
$chkMdpDejaInit.FlatAppearance.CheckedBackColor = $cWarning
$chkMdpDejaInit.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(60, 60, 64)
$chkMdpDejaInit.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
$chkMdpDejaInit.Cursor = [Windows.Forms.Cursors]::Hand

# Mon-AD n'affiche pas une date d'initialisation mais le nombre de jours restants
# avant de devoir changer le mot de passe : on saisit donc ce nombre de jours, et
# l'outil en déduit la date d'init (aujourd'hui - (365 - X)), affichée juste à côté.
# C'est cette date calculée qui part dans le mail et la note ServiceNow.
$lblDateInit = New-Object Windows.Forms.Label
$lblDateInit.Text = "Expire dans :"
$lblDateInit.AutoSize = $true
$lblDateInit.Location = New-Object Drawing.Point($col2Lbl, 98)
$lblDateInit.ForeColor = $cTextSecondary
$lblDateInit.Visible = $false

$txtJoursInit = New-Object Windows.Forms.TextBox
$txtJoursInit.Location = New-Object Drawing.Point($col2In, 95)
$txtJoursInit.Width = 60
$txtJoursInit.Text = "$script:DureeValiditeMdp"
$txtJoursInit.MaxLength = 3
$txtJoursInit.TextAlign = 'Center'
$txtJoursInit.BackColor = $cSurface; $txtJoursInit.ForeColor = $cTextPrimary
$txtJoursInit.BorderStyle = 'FixedSingle'; $txtJoursInit.Font = [Drawing.Font]::new("Segoe UI", 10)
$txtJoursInit.Visible = $false

$lblJoursUnite = New-Object Windows.Forms.Label
$lblJoursUnite.Text = "jours  ="
$lblJoursUnite.AutoSize = $true
$lblJoursUnite.Location = New-Object Drawing.Point(($col2In + 68), 98)
$lblJoursUnite.ForeColor = $cTextSecondary
$lblJoursUnite.Visible = $false

# Date calculée : LA valeur à reporter dans Mon-AD / la note. Mise en évidence
# en violet ; passe en rouge avec un gabarit si la saisie n'est pas exploitable.
$lblDateCalc = New-Object Windows.Forms.Label
$lblDateCalc.AutoSize = $true
$lblDateCalc.Location = New-Object Drawing.Point(($col2In + 130), 97)
$lblDateCalc.ForeColor = $cAccentViolet
$lblDateCalc.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$lblDateCalc.Visible = $false

# Date d'initialisation déduite de la saisie, au format dd/MM/yyyy.
# $null si le nombre de jours saisi est vide ou invalide (la génération du .msg
# s'appuie dessus pour bloquer avec un message clair).
function Get-DateInitSaisie {
    $jours = ConvertTo-NombreDeJours $txtJoursInit.Text -Max $script:DureeValiditeMdp
    if ($null -eq $jours) { return $null }
    return (Get-DateInitDepuisJoursRestants $jours).ToString('dd/MM/yyyy')
}

# Rafraîchit l'étiquette de date calculée affichée à droite du champ.
function Update-DateInitCalculee {
    $d = Get-DateInitSaisie
    if ($d) {
        $lblDateCalc.Text = $d
        $lblDateCalc.ForeColor = $cAccentViolet
    } else {
        $lblDateCalc.Text = "jj/mm/aaaa"
        $lblDateCalc.ForeColor = $cDanger
    }
}

$chkMdpDejaInit.Add_CheckedChanged({
    $checked = $chkMdpDejaInit.Checked
    $lblDateInit.Visible = $checked
    $txtJoursInit.Visible = $checked
    $lblJoursUnite.Visible = $checked
    $lblDateCalc.Visible = $checked
    if ($checked) {
        Update-DateInitCalculee
        $chkMdpDejaInit.ForeColor = $cWhite
        $btnGenPwd.Enabled = $false
        $btnGenPwd.BackColor = $cBorder
        $txtPwd.Text = ""
        $txtPwd.BackColor = [Drawing.Color]::FromArgb(50, 50, 50)
        $btnGenMsg.Enabled = $true
    } else {
        $chkMdpDejaInit.ForeColor = $cWarning
        $btnGenPwd.Enabled = $true
        $btnGenPwd.BackColor = $cAccentViolet
        $txtPwd.BackColor = $cSurface
        $btnGenMsg.Enabled = ($txtPwd.Text -ne "")
    }
    Update-Preview
})

# Saisie : uniquement des chiffres (les autres touches sont ignorées à la source,
# on ne peut donc pas taper une valeur non exploitable).
$txtJoursInit.Add_KeyPress({
    param($s, $e)
    if (-not ([char]::IsControl($e.KeyChar) -or [char]::IsDigit($e.KeyChar))) { $e.Handled = $true }
})

# Flèches ↑ / ↓ pour ajuster le décompte au clavier (confort de l'ancien calendrier).
$txtJoursInit.Add_KeyDown({
    param($s, $e)
    if ($e.KeyCode -ne [Windows.Forms.Keys]::Up -and $e.KeyCode -ne [Windows.Forms.Keys]::Down) { return }
    $jours = ConvertTo-NombreDeJours $txtJoursInit.Text -Max $script:DureeValiditeMdp
    if ($null -eq $jours) { $jours = $script:DureeValiditeMdp }
    if ($e.KeyCode -eq [Windows.Forms.Keys]::Up) { if ($jours -lt $script:DureeValiditeMdp) { $jours++ } } elseif ($jours -gt 0) { $jours-- }
    $txtJoursInit.Text = "$jours"
    $txtJoursInit.SelectionStart = $txtJoursInit.Text.Length
    $e.Handled = $true
    $e.SuppressKeyPress = $true
})

$txtJoursInit.Add_TextChanged({ Update-DateInitCalculee; Update-Preview })
Update-DateInitCalculee

$panelForm.Controls.AddRange(@($lblRITM,$txtRITM,$lblEmail,$txtEmail,$lblNomPrenom,$txtNomPrenom,$btnVerifHomo,$lblHomo,$btnVerifDoublon,$lblDoublon,$chkMdpDejaInit,$lblDateInit,$txtJoursInit,$lblJoursUnite,$lblDateCalc,$picHeader,$picSignature,$lblStatusImg,$chkAutoBulle))

# --- Layout responsive du panneau formulaire ---
function Layout-FormPanel {
    $pw = $panelForm.ClientSize.Width
    $imgArea = 225
    $margin = 15
    $gap = 15
    $labelW = 150
    $avail = $pw - $imgArea - $margin
    $colW = [int](($avail - $gap) / 2)
    $inW = [Math]::Max(80, $colW - $labelW)

    $txtRITM.Width = $inW
    $txtNomPrenom.Width = $inW

    $c2x = $margin + $colW + $gap
    $lblEmail.Left = $c2x
    $txtEmail.Left = $c2x + $labelW
    $txtEmail.Width = $inW

    # Ligne 4 : boutons de vérification (colonne des libellés) + états alignés sur les champs.
    $lblHomo.Width = $inW
    $btnVerifDoublon.Left = $c2x
    $lblDoublon.Left = $c2x + $labelW
    $lblDoublon.Width = $inW

    # Ligne 3, colonne 2 : décompte de jours + date calculée, alignés sur l'e-mail.
    $lblDateInit.Left = $c2x
    $txtJoursInit.Left = $c2x + $labelW
    $lblJoursUnite.Left = $txtJoursInit.Right + 8
    $lblDateCalc.Left = $lblJoursUnite.Right + 8
}
$panelForm.Add_Resize({ Layout-FormPanel })
Layout-FormPanel

# --- Barre d'actions ---
$panelActions = New-Object Windows.Forms.Panel
$panelActions.Location = New-Object Drawing.Point(20, 264)
$panelActions.Size = New-Object Drawing.Size(1045, 50)
$panelActions.BackColor = $cBgSecondary
$panelActions.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right
$form.Controls.Add($panelActions)

$btnGenPwd = New-Object Windows.Forms.Button
$btnGenPwd.Text = "Générer mot de passe"
$btnGenPwd.Location = New-Object Drawing.Point(15, 8)
$btnGenPwd.Size = New-Object Drawing.Size(190, 34)
$btnGenPwd.FlatStyle = 'Flat'
$btnGenPwd.FlatAppearance.BorderSize = 0
$btnGenPwd.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
$btnGenPwd.BackColor = $cAccentViolet
$btnGenPwd.ForeColor = $cWhite
$btnGenPwd.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$btnGenPwd.Cursor = [Windows.Forms.Cursors]::Hand

$txtPwd = New-Object Windows.Forms.TextBox
$txtPwd.Location = New-Object Drawing.Point(215, 12)
$txtPwd.Width = 210; $txtPwd.ReadOnly = $true
$txtPwd.BackColor = $cSurface; $txtPwd.ForeColor = $cAccentViolet
$txtPwd.BorderStyle = 'FixedSingle'
$txtPwd.Font = [Drawing.Font]::new("Consolas", 11)

$btnGenMsg = New-Object Windows.Forms.Button
$btnGenMsg.Text = "Générer .msg + Maj note Snow"
$btnGenMsg.Location = New-Object Drawing.Point(445, 8)
$btnGenMsg.Size = New-Object Drawing.Size(250, 34)
$btnGenMsg.FlatStyle = 'Flat'
$btnGenMsg.FlatAppearance.BorderSize = 0
$btnGenMsg.FlatAppearance.MouseOverBackColor = $cAccentBlueHover
$btnGenMsg.BackColor = $cAccentBlue
$btnGenMsg.ForeColor = $cWhite
$btnGenMsg.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$btnGenMsg.Cursor = [Windows.Forms.Cursors]::Hand
$btnGenMsg.Enabled = $false

$btnReset = New-Object Windows.Forms.Button
$btnReset.Text = "Réinitialiser"
$btnReset.Location = New-Object Drawing.Point(715, 8)
$btnReset.Size = New-Object Drawing.Size(140, 34)
$btnReset.FlatStyle = 'Flat'
$btnReset.FlatAppearance.BorderSize = 1
$btnReset.FlatAppearance.BorderColor = $cBorder
$btnReset.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(62, 62, 66)
$btnReset.BackColor = $cBgSecondary
$btnReset.ForeColor = $cTextPrimary
$btnReset.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$btnReset.Cursor = [Windows.Forms.Cursors]::Hand
$btnReset.Add_Click({
    Set-ModeHomonyme $false
    Set-ModeDoublon $false
    $global:HomoIgnore = $null
    $global:HomoComptes = @()
    $global:HomoDernierNom = $null
    $global:DoublonIgnore = $null
    $global:DoublonTaches = @()
    $global:DoublonDerniereCle = $null
    $txtRITM.Text = ""
    $txtEmail.Text = ""
    $txtNomPrenom.Text = ""
    $txtPwd.Text = ""
    $chkMdpDejaInit.Checked = $false
    $txtJoursInit.Text = "$script:DureeValiditeMdp"
    $btnGenPwd.Enabled = $true
    $btnGenPwd.BackColor = $cAccentViolet
    $txtPwd.BackColor = $cSurface
    Remove-FichiersMotDePasse
    $global:CopyDateInit = $null
    $global:CopyOU = "(à définir)"
    $global:CopyEmailBenef = "(à définir)"
    $rtbCopy.Text = Get-CopyBlockText
    $btnGenMsg.Enabled = $false
    Update-Preview
})

$panelActions.Controls.AddRange(@($btnGenPwd, $txtPwd, $btnGenMsg, $btnReset))

# --- Panneau d'éléments à copier (Note ServiceNow, à gauche) ---
$panelCopy = New-Object Windows.Forms.Panel
$panelCopy.Location = New-Object Drawing.Point(20, 324)
$panelCopy.Size = New-Object Drawing.Size(615, 137)
$panelCopy.BackColor = $cBgSecondary
$panelCopy.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left
$form.Controls.Add($panelCopy)

$lblCopyTitle = New-Object Windows.Forms.Label
$lblCopyTitle.Text = "Note ServiceNow"
$lblCopyTitle.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$lblCopyTitle.ForeColor = $cTextSecondary
$lblCopyTitle.Location = New-Object Drawing.Point(15, 6)
$lblCopyTitle.AutoSize = $true
$panelCopy.Controls.Add($lblCopyTitle)

$global:CopyOU = "(à définir)"
$global:CopyEmailBenef = "(à définir)"

$global:CopyDateInit = $null

# Mode « homonymes » : actif quand ServiceNow renvoie plusieurs comptes au même nom.
$global:ModeHomonyme = $false
$global:HomoComptes = @()        # comptes portant exactement le nom saisi
$global:HomoCpDemande = $null    # CP communiqué dans la RITM (choisi par l'opérateur)
$global:HomoIgnore = $null       # nom normalisé pour lequel l'opérateur a écarté l'alerte
$global:HomoDernierNom = $null   # dernier nom envoyé à la vérification
$global:HomoActif = $false       # homonymes détectés et non écartés

# Mode « doublon » : une autre RITM existe déjà pour ce bénéficiaire (prioritaire).
$global:ModeDoublon = $false
$global:DoublonActif = $false        # doublon détecté et non écarté
$global:DoublonTaches = @()          # tâches en doublon (Select-Doublons)
$global:DoublonRitm = $null          # RITM citée dans le mail d'annulation
$global:DoublonIgnore = $null        # clé « RITM|nom » pour laquelle l'alerte a été écartée
$global:DoublonDerniereCle = $null   # dernière clé envoyée à la vérification

function Get-CopyBlockText {
    if ($global:ModeDoublon) {
        $r = if ($global:DoublonRitm) { $global:DoublonRitm } else { "(à choisir)" }
        return @(
            "***Annulation - Doublon***",
            "Doublon de $r",
            "Mail envoyé au demandeur"
        ) -join "`r`n"
    }
    if ($global:ModeHomonyme) {
        $cp = if ($global:HomoCpDemande) { $global:HomoCpDemande } else { "(à choisir)" }
        $trouves = (Get-CpTrouves $global:HomoComptes $global:HomoCpDemande) -join ', '
        if (-not $global:HomoCpDemande) { $trouves = "(à choisir)" }
        return @(
            "***Homonyme détecté***",
            "CP demandé > $cp",
            "CP trouvé(s) > $trouves",
            "Mail envoyé au demandeur, en attente de retour"
        ) -join "`r`n"
    }
    if ($global:CopyDateInit) {
        $header = "***Vérifications Mon-AD : Mot de passe déjà initialisé le $($global:CopyDateInit)***"
    } else {
        $header = "***Mot de passe initialisé***"
    }
    return @(
        $header,
        "Demande recevable",
        "Pas d'homonyme",
        "Pas de doublon de demande",
        "Compte approvisionné",
        "OU > $($global:CopyOU)",
        "Adresse de messagerie > $($global:CopyEmailBenef)"
    ) -join "`r`n"
}

# Message de clôture à destination du demandeur (« Note Utilisateur »).
# Le texte change selon le mode (case « Mot de passe déjà initialisé »).
function Get-MessageDemandeurText {
    if ($global:ModeDoublon) {
        $r = if ($global:DoublonRitm) { $global:DoublonRitm } else { "(RITM à choisir)" }
        $corps = "Nous annulons votre sollicitation car vous avez déjà une demande en cours de traitement ou réalisée $r pour ce même besoin.`r`n`r`nEn vous remerciant de votre compréhension."
    } elseif ($global:ModeHomonyme) {
        $corps = "Nous avons constaté la présence d'autres CP pour ce bénéficiaire. Un mail vous a été envoyé afin de savoir s'il s'agit d'un homonyme ou d'un changement de statut. Nous restons dans l'attente de votre retour."
    } elseif ($chkMdpDejaInit.Checked) {
        $corps = "Le compte est bien activé. Le mot de passe n'a pas été modifié, car il avait déjà été initialisé."
    } else {
        $corps = "Le compte a bien été activé. Le mot de passe a été envoyé par mail au demandeur."
    }
    return @(
        "Bonjour,",
        "",
        $corps,
        "",
        "Cordialement,",
        "L'assistance bureautique."
    ) -join "`r`n"
}

$rtbCopy = New-Object Windows.Forms.RichTextBox
$rtbCopy.Location = New-Object Drawing.Point(15, 26)
$rtbCopy.Size = New-Object Drawing.Size(490, 102)
$rtbCopy.BackColor = $cSurface
$rtbCopy.ForeColor = $cTextPrimary
$rtbCopy.Font = [Drawing.Font]::new("Segoe UI", 9)
$rtbCopy.ReadOnly = $true
$rtbCopy.BorderStyle = 'None'
$rtbCopy.Text = Get-CopyBlockText
$rtbCopy.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right

$btnCopyAll = New-Object Windows.Forms.Button
$btnCopyAll.Text = "Copier"
$btnCopyAll.Location = New-Object Drawing.Point(515, 26)
$btnCopyAll.Size = New-Object Drawing.Size(85, 102)
$btnCopyAll.FlatStyle = 'Flat'
$btnCopyAll.FlatAppearance.BorderSize = 0
$btnCopyAll.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
$btnCopyAll.BackColor = $cAccentViolet
$btnCopyAll.ForeColor = $cWhite
$btnCopyAll.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$btnCopyAll.Cursor = [Windows.Forms.Cursors]::Hand
$btnCopyAll.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$btnCopyAll.Add_Click({
    [System.Windows.Forms.Clipboard]::SetText($rtbCopy.Text)
    $this.Text = "Copié !"
    $this.BackColor = [Drawing.Color]::FromArgb(39, 174, 96)
    $t = New-Object Windows.Forms.Timer
    $t.Interval = 800; $t.Tag = $this
    $t.Add_Tick({
        $btn = $this.Tag
        $btn.Text = "Copier tout"
        $btn.BackColor = [Drawing.Color]::FromArgb(155, 89, 182)
        $this.Stop(); $this.Dispose()
    })
    $t.Start()
})

$panelCopy.Controls.AddRange(@($lblCopyTitle, $rtbCopy, $btnCopyAll))

# --- Panneau « Note Utilisateur » (message au demandeur, à droite) ---
$panelMsg = New-Object Windows.Forms.Panel
$panelMsg.Location = New-Object Drawing.Point(650, 324)
$panelMsg.Size = New-Object Drawing.Size(415, 137)
$panelMsg.BackColor = $cBgSecondary
$panelMsg.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left
$form.Controls.Add($panelMsg)

$lblMsgTitle = New-Object Windows.Forms.Label
$lblMsgTitle.Text = "Note Utilisateur"
$lblMsgTitle.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$lblMsgTitle.ForeColor = $cTextSecondary
$lblMsgTitle.Location = New-Object Drawing.Point(15, 6)
$lblMsgTitle.AutoSize = $true

$rtbMsg = New-Object Windows.Forms.RichTextBox
$rtbMsg.Location = New-Object Drawing.Point(15, 26)
$rtbMsg.Size = New-Object Drawing.Size(290, 102)
$rtbMsg.BackColor = $cSurface
$rtbMsg.ForeColor = $cTextPrimary
$rtbMsg.Font = [Drawing.Font]::new("Segoe UI", 9)
$rtbMsg.ReadOnly = $true
$rtbMsg.BorderStyle = 'None'
$rtbMsg.Text = Get-MessageDemandeurText
$rtbMsg.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right

$btnCopyMsg = New-Object Windows.Forms.Button
$btnCopyMsg.Text = "Copier"
$btnCopyMsg.Location = New-Object Drawing.Point(315, 26)
$btnCopyMsg.Size = New-Object Drawing.Size(85, 102)
$btnCopyMsg.FlatStyle = 'Flat'
$btnCopyMsg.FlatAppearance.BorderSize = 0
$btnCopyMsg.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
$btnCopyMsg.BackColor = $cAccentViolet
$btnCopyMsg.ForeColor = $cWhite
$btnCopyMsg.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$btnCopyMsg.Cursor = [Windows.Forms.Cursors]::Hand
$btnCopyMsg.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$btnCopyMsg.Add_Click({
    [System.Windows.Forms.Clipboard]::SetText($rtbMsg.Text)
    $this.Text = "Copié !"
    $this.BackColor = [Drawing.Color]::FromArgb(39, 174, 96)
    $t = New-Object Windows.Forms.Timer
    $t.Interval = 800; $t.Tag = $this
    $t.Add_Tick({
        $btn = $this.Tag
        $btn.Text = "Copier"
        $btn.BackColor = [Drawing.Color]::FromArgb(155, 89, 182)
        $this.Stop(); $this.Dispose()
    })
    $t.Start()
})

$panelMsg.Controls.AddRange(@($lblMsgTitle, $rtbMsg, $btnCopyMsg))

# Répartit la largeur disponible entre les deux notes (responsive côte à côte).
# La Note ServiceNow (gauche) est un peu plus large que la Note Utilisateur (droite).
function Layout-CopyPanels {
    $totalW = $form.ClientSize.Width - 40
    if ($totalW -lt 200) { return }
    $gap = 15
    $leftW = [int](($totalW - $gap) * 0.595)
    $panelCopy.Left = 20
    $panelCopy.Width = $leftW
    $panelMsg.Left = 20 + $leftW + $gap
    $panelMsg.Width = $totalW - $gap - $leftW
}
$form.Add_Resize({ Layout-CopyPanels })
Layout-CopyPanels

# --- Aperçu du sujet ---
$lblSubjectLabel = New-Object Windows.Forms.Label
$lblSubjectLabel.Text = "Objet :"
$lblSubjectLabel.Location = New-Object Drawing.Point(20, 471)
$lblSubjectLabel.AutoSize = $true
$lblSubjectLabel.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$lblSubjectLabel.ForeColor = $cTextSecondary
$form.Controls.Add($lblSubjectLabel)

$txtSubjectPreview = New-Object Windows.Forms.Label
$txtSubjectPreview.Location = New-Object Drawing.Point(75, 467)
$txtSubjectPreview.Size = New-Object Drawing.Size(990, 28)
$txtSubjectPreview.BackColor = $cSurface
$txtSubjectPreview.ForeColor = $cAccentViolet
$txtSubjectPreview.Font = [Drawing.Font]::new("Segoe UI", 11, [Drawing.FontStyle]::Bold)
$txtSubjectPreview.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
$txtSubjectPreview.Padding = New-Object Windows.Forms.Padding(10, 0, 0, 0)
$txtSubjectPreview.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right
$form.Controls.Add($txtSubjectPreview)

# --- Aperçu du message ---
$lblPreviewLabel = New-Object Windows.Forms.Label
$lblPreviewLabel.Text = "Aperçu du message"
$lblPreviewLabel.Location = New-Object Drawing.Point(20, 508)
$lblPreviewLabel.AutoSize = $true
$lblPreviewLabel.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
$lblPreviewLabel.ForeColor = $cTextSecondary
$form.Controls.Add($lblPreviewLabel)

$panelPreview = New-Object Windows.Forms.Panel
$panelPreview.Location = New-Object Drawing.Point(20, 531)
$panelPreview.Size = New-Object Drawing.Size(1045, 341)
$panelPreview.BackColor = $cBgSecondary
$panelPreview.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right -bor [Windows.Forms.AnchorStyles]::Bottom
$form.Controls.Add($panelPreview)

$webBrowser = New-Object Windows.Forms.WebBrowser
$webBrowser.Dock = 'Fill'
$webBrowser.ScriptErrorsSuppressed = $true
# Aperçu en lecture seule : aucune navigation hors du contenu généré (un lien cliqué
# ne charge rien), pas de menu contextuel, de raccourcis ni de glisser-déposer.
$webBrowser.IsWebBrowserContextMenuEnabled = $false
$webBrowser.WebBrowserShortcutsEnabled = $false
$webBrowser.AllowWebBrowserDrop = $false
$webBrowser.Add_Navigating({ param($s, $e) if ($e.Url.AbsoluteUri -ne 'about:blank') { $e.Cancel = $true } })
$panelPreview.Controls.Add($webBrowser)

# --- Bouton « Copier tout » visible uniquement quand l'aperçu est masqué ---
# Les deux notes étant cachées en mode replié, ce bouton permet de copier
# d'un clic la Note ServiceNow + la Note Utilisateur.
$btnCopyCollapsed = New-Object Windows.Forms.Button
$btnCopyCollapsed.Text = "📋  Copier tout (Note ServiceNow + Note Utilisateur)"
$btnCopyCollapsed.Location = New-Object Drawing.Point(20, 322)
$btnCopyCollapsed.Size = New-Object Drawing.Size(1045, 36)
$btnCopyCollapsed.FlatStyle = 'Flat'
$btnCopyCollapsed.FlatAppearance.BorderSize = 0
$btnCopyCollapsed.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
$btnCopyCollapsed.BackColor = $cAccentViolet
$btnCopyCollapsed.ForeColor = $cWhite
$btnCopyCollapsed.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$btnCopyCollapsed.Cursor = [Windows.Forms.Cursors]::Hand
$btnCopyCollapsed.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Left -bor [Windows.Forms.AnchorStyles]::Right
$btnCopyCollapsed.Visible = $false
$btnCopyCollapsed.Add_Click({
    # « Copier tout » = DEUX copies -> deux entrées distinctes dans l'historique du
    # presse-papiers (Win+V), messages bruts (sans en-tête).
    #   1) note Utilisateur copiée tout de suite ;
    #   2) note ServiceNow copiée en DIFFÉRÉ via un Timer.
    # Le différé est INDISPENSABLE : il laisse la boucle de messages tourner pour que
    # le service d'historique Windows (cbdhsvc) « photographie » la 1re copie AVANT
    # qu'elle soit remplacée par la 2e. Un Start-Sleep bloquant échoue (seule la
    # dernière note survit). Résultat : Ctrl+V colle la note ServiceNow (dernière
    # copiée), et Win+V propose aussi la note Utilisateur.
    [System.Windows.Forms.Clipboard]::SetText((Get-MessageDemandeurText))
    $this.Text = "Copié ×2 !"
    $this.BackColor = [Drawing.Color]::FromArgb(39, 174, 96)
    $t = New-Object Windows.Forms.Timer
    $t.Interval = 350; $t.Tag = $this
    $t.Add_Tick({
        $this.Stop()
        $btn = $this.Tag
        try { [System.Windows.Forms.Clipboard]::SetText((Get-CopyBlockText)) } catch {}
        $btn.Text = "📋  Copier tout (Note ServiceNow + Note Utilisateur)"
        $btn.BackColor = [Drawing.Color]::FromArgb(155, 89, 182)
        $this.Dispose()
    })
    $t.Start()
})
$form.Controls.Add($btnCopyCollapsed)

# --- Bouton repli/dépli du bas (objet + aperçu + notes) ---
# Gagne de la place sur les petits écrans : un clic masque tout le bas et réduit
# la hauteur de la fenêtre ; re-clic restaure.
$global:PreviewCollapsed = $false
$btnTogglePreview = New-Object Windows.Forms.Button
$btnTogglePreview.Text = "▼ Aperçu"
$btnTogglePreview.Location = New-Object Drawing.Point(870, 8)
$btnTogglePreview.Size = New-Object Drawing.Size(160, 34)
$btnTogglePreview.FlatStyle = 'Flat'
$btnTogglePreview.FlatAppearance.BorderSize = 1
$btnTogglePreview.FlatAppearance.BorderColor = $cBorder
$btnTogglePreview.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(62, 62, 66)
$btnTogglePreview.BackColor = $cBgSecondary
$btnTogglePreview.ForeColor = $cTextPrimary
$btnTogglePreview.Font = [Drawing.Font]::new("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$btnTogglePreview.Cursor = [Windows.Forms.Cursors]::Hand
$btnTogglePreview.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
# Applique l'état replié/déplié (visibilité + taille de fenêtre). Appelée par le
# bouton et au démarrage pour restaurer la préférence persistée (state.json).
function Set-PreviewCollapsed([bool]$Collapsed) {
    $global:PreviewCollapsed = $Collapsed
    $vis = -not $Collapsed
    $panelCopy.Visible = $vis
    $panelMsg.Visible = $vis
    $lblSubjectLabel.Visible = $vis
    $txtSubjectPreview.Visible = $vis
    $lblPreviewLabel.Visible = $vis
    $panelPreview.Visible = $vis
    $btnCopyCollapsed.Visible = $Collapsed
    if ($Collapsed) {
        $btnTogglePreview.Text = "▶ Aperçu"
        $form.MinimumSize = New-Object Drawing.Size(1095, 382)
        $form.Height = 414
    } else {
        $btnTogglePreview.Text = "▼ Aperçu"
        $form.Height = 920
        $form.MinimumSize = New-Object Drawing.Size(1095, 650)
    }
}
$btnTogglePreview.Add_Click({
    Set-PreviewCollapsed (-not $global:PreviewCollapsed)
    # Mémorise la préférence pour les prochains lancements.
    $global:Ctx.State.PreviewCollapsed = [bool]$global:PreviewCollapsed
    try { Save-AppState $global:Ctx.State } catch { }
})
$panelActions.Controls.Add($btnTogglePreview)
# Restaure la préférence « aperçu replié » du dernier lancement.
if ($global:Ctx.State.PreviewCollapsed) { Set-PreviewCollapsed $true }

# --- Logique de l'aperçu ---
function Update-Preview {
    $ritm = if($txtRITM.Text){$txtRITM.Text}else{"RITMXXXXX"}
    $nomPrenom = if($txtNomPrenom.Text){$txtNomPrenom.Text}else{"Prénom NOM"}
    if ($global:ModeDoublon) {
        $objet = "$ritm - Annulation doublon $nomPrenom"
        $txtSubjectPreview.Text = $objet
        $rD = if ($global:DoublonRitm) { $global:DoublonRitm } else { "(RITM à choisir)" }
        $html = Get-CorpsMessageHTML_Doublon_Preview $objet $rD $cheminHeader $cheminSignature
    } elseif ($global:ModeHomonyme) {
        $objet = "$ritm - Vérification homonyme $nomPrenom"
        $txtSubjectPreview.Text = $objet
        $cpD = if ($global:HomoCpDemande) { $global:HomoCpDemande } else { "(à choisir)" }
        $cpT = if ($global:HomoCpDemande) { (Get-CpTrouves $global:HomoComptes $global:HomoCpDemande) -join ', ' } else { "(à choisir)" }
        $html = Get-CorpsMessageHTML_Homonyme_Preview $objet $nomPrenom $cpD $cpT $cheminHeader $cheminSignature
    } elseif ($chkMdpDejaInit.Checked) {
        # Décompte non exploitable : l'aperçu montre un gabarit plutôt qu'une fausse date.
        $dateInit = Get-DateInitSaisie
        if (-not $dateInit) { $dateInit = "jj/mm/aaaa" }
        $objet = "$ritm - Mot de passe déjà initialisé $nomPrenom"
        $txtSubjectPreview.Text = $objet
        $html = Get-CorpsMessageHTML_DejaInit_Preview $objet $nomPrenom $dateInit $cheminHeader $cheminSignature
    } else {
        $objet = "$ritm - Notification mot de passe $nomPrenom"
        $txtSubjectPreview.Text = $objet
        $html = Get-CorpsMessageHTML_Preview $objet $nomPrenom $cheminHeader $cheminSignature
    }
    $rtbMsg.Text = Get-MessageDemandeurText
    $webBrowser.DocumentText = $html
}

# --- Vérifications ServiceNow : homonymes (lib/Homonymes.ps1) et doublons de
#     demande (lib/Doublons.ps1), exécutées par la page cachée (lib/SnowPage.ps1) ---

# Style commun des étiquettes d'état (à droite des boutons « Vérif. … »).
#   Etat : idle | info | auth | erreur | ok | alerte | ignore
function Set-StatutLabel {
    param($Label, [string]$Etat, [string]$Texte, $CouleurAlerte)
    $Label.Text = $Texte
    $global:TipHomo.SetToolTip($Label, $Texte)
    $Label.Font = [Drawing.Font]::new("Segoe UI", 9)
    $Label.BackColor = $cBgSecondary
    $Label.Cursor = [Windows.Forms.Cursors]::Default
    switch ($Etat) {
        'ok'     { $Label.ForeColor = $cSuccess }
        'auth'   { $Label.ForeColor = $cWarning; $Label.Cursor = [Windows.Forms.Cursors]::Hand }
        'erreur' { $Label.ForeColor = $cDanger;  $Label.Cursor = [Windows.Forms.Cursors]::Hand }
        'ignore' { $Label.ForeColor = $CouleurAlerte; $Label.Cursor = [Windows.Forms.Cursors]::Hand }
        'alerte' {
            $Label.BackColor = $CouleurAlerte; $Label.ForeColor = $cWhite
            $Label.Font = [Drawing.Font]::new("Segoe UI", 9, [Drawing.FontStyle]::Bold)
            $Label.Cursor = [Windows.Forms.Cursors]::Hand
        }
        default  { $Label.ForeColor = $cTextSecondary }
    }
}
# Etat homonymes : idle | info | auth | erreur | ok | homonyme | ignore
function Set-StatutHomo {
    param([string]$Etat, [string]$Texte)
    $global:HomoEtat = $Etat
    Set-StatutLabel $lblHomo $(if ($Etat -eq 'homonyme') { 'alerte' } else { $Etat }) $Texte $cHomonyme
}
# Etat doublons : idle | info | auth | erreur | ok | doublon | ignore
function Set-StatutDoublon {
    param([string]$Etat, [string]$Texte)
    $global:DoublonEtat = $Etat
    Set-StatutLabel $lblDoublon $(if ($Etat -eq 'doublon') { 'alerte' } else { $Etat }) $Texte $cDanger
}

# Mode du formulaire : 'normal', 'homonyme' (mail au demandeur sur les CP trouvés) ou
# 'doublon' (annulation : mail au demandeur citant l'autre RITM). Dans les deux modes
# spéciaux, seule la génération du mail reste active (pas de mot de passe, pas de
# vérification Mon-AD / OU). Le doublon l'emporte : la demande est annulée, la question
# des homonymes ne se pose plus.
$global:ModeFormulaire = 'normal'
function Update-ModeFormulaire {
    $mode = if ($global:DoublonActif) { 'doublon' } elseif ($global:HomoActif) { 'homonyme' } else { 'normal' }
    $global:ModeDoublon = ($mode -eq 'doublon')
    $global:ModeHomonyme = ($mode -eq 'homonyme')
    if ($mode -ne $global:ModeFormulaire) {
        $global:ModeFormulaire = $mode
        if ($mode -eq 'normal') {
            $chkMdpDejaInit.Enabled = $true
            $btnGenPwd.Enabled = $true
            $btnGenPwd.BackColor = $cAccentViolet
            $btnGenMsg.Text = "Générer .msg + Maj note Snow"
            $btnGenMsg.BackColor = $cAccentBlue
            $btnGenMsg.FlatAppearance.MouseOverBackColor = $cAccentBlueHover
            $btnGenMsg.Enabled = ($txtPwd.Text -ne "")
            $txtSubjectPreview.ForeColor = $cAccentViolet
        } else {
            $coul  = if ($mode -eq 'doublon') { $cDanger } else { $cHomonyme }
            $hover = if ($mode -eq 'doublon') { $cDangerHover } else { $cHomonymeHover }
            if ($chkMdpDejaInit.Checked) { $chkMdpDejaInit.Checked = $false }
            $chkMdpDejaInit.Enabled = $false
            $btnGenPwd.Enabled = $false
            $btnGenPwd.BackColor = $cBorder
            $btnGenMsg.Text = if ($mode -eq 'doublon') { "Générer mail doublon" } else { "Générer mail homonyme" }
            $btnGenMsg.BackColor = $coul
            $btnGenMsg.FlatAppearance.MouseOverBackColor = $hover
            $btnGenMsg.Enabled = $true
            $txtSubjectPreview.ForeColor = $coul
        }
    }
    $rtbCopy.Text = Get-CopyBlockText
    Update-Preview
}
function Set-ModeHomonyme {
    param([bool]$Actif)
    $global:HomoActif = $Actif
    if (-not $Actif) { $global:HomoCpDemande = $null }
    Update-ModeFormulaire
}
function Set-ModeDoublon {
    param([bool]$Actif)
    $global:DoublonActif = $Actif
    if (-not $Actif) { $global:DoublonRitm = $null }
    Update-ModeFormulaire
}

# Rappels de la page cachée pour un type de vérification (créée à la 1re demande).
function Initialize-VerifSnow {
    param([string]$Type)
    if ($Type -eq 'homo') {
        Initialize-SnowEngine -LibDir (Join-Path $baseDir 'lib\webview2') -DataDir $dataDir -Type 'homo' `
            -OnResultat { param($n, $r) Set-ResultatHomonymes $n $r } `
            -OnStatut { param($etat, $texte) if ($global:HomoEtat -ne 'homonyme' -or $etat -ne 'info') { Set-StatutHomo $etat $texte } }
    } else {
        Initialize-SnowEngine -LibDir (Join-Path $baseDir 'lib\webview2') -DataDir $dataDir -Type 'doublon' `
            -OnResultat { param($c, $r) Set-ResultatDoublons $c $r } `
            -OnStatut { param($etat, $texte) if ($global:DoublonEtat -ne 'doublon' -or $etat -ne 'info') { Set-StatutDoublon $etat $texte } }
    }
}

# ---- Homonymes ----

# Texte de la pastille rose selon que le CP demandé a été choisi ou non.
function Update-StatutHomonyme {
    $n = @($global:HomoComptes).Count
    if ($global:HomoCpDemande) {
        $tr = (Get-CpTrouves $global:HomoComptes $global:HomoCpDemande) -join ', '
        Set-StatutHomo 'homonyme' "⚠ HOMONYMES : $($global:HomoCpDemande) / $tr"
        $global:TipHomo.SetToolTip($lblHomo, "Homonymes détectés`r`nCP demandé : $($global:HomoCpDemande)`r`nCP trouvé(s) : $tr`r`nCliquer pour modifier le choix.")
    } else {
        Set-StatutHomo 'homonyme' "⚠ $n HOMONYMES DÉTECTÉS (cliquer)"
        $global:TipHomo.SetToolTip($lblHomo, "$n comptes portent ce nom dans ServiceNow.`r`nCliquer pour désigner le CP communiqué dans la RITM.")
    }
}

# Résultat ServiceNow : comptes ramenés pour le nom vérifié.
function Set-ResultatHomonymes {
    param([string]$NomPrenom, $Records)
    if ($NomPrenom -ne $txtNomPrenom.Text.Trim()) { return }   # nom modifié entre-temps
    $comptes = @(Select-Homonymes $Records $NomPrenom)
    $global:HomoComptes = $comptes
    $global:HomoCpDemande = $null
    if (Test-PresenceHomonymes $comptes) {
        Write-AppLog "[HOMO] Homonymes détectés : $($comptes.Count) comptes au même nom."
        if ($global:HomoIgnore -eq (ConvertTo-NomNormalise $NomPrenom)) {
            Set-ModeHomonyme $false
            Set-StatutHomo 'ignore' "Homonymes écartés ($($comptes.Count) comptes) — cliquer pour revoir"
            return
        }
        Set-ModeHomonyme $true
        Update-StatutHomonyme
    } else {
        Set-ModeHomonyme $false
        if ($comptes.Count -eq 1) { Set-StatutHomo 'ok' "✔ Pas d'homonyme (CP $($comptes[0].user_name))" }
        else { Set-StatutHomo 'ok' "✔ Pas d'homonyme (aucun compte à ce nom)" }
    }
}

# Lance (ou relance avec -Force) la vérification pour le nom saisi.
function Invoke-VerifHomonymes {
    param([switch]$Force)
    $nom = $txtNomPrenom.Text.Trim()
    if (-not (Get-RequeteHomonymes $nom)) {
        $global:HomoDernierNom = $null
        $global:HomoComptes = @()
        Set-ModeHomonyme $false
        Set-StatutHomo 'idle' 'Saisir le nom et le prénom'
        return
    }
    if (-not $Force -and $nom -eq $global:HomoDernierNom) { return }
    $global:HomoDernierNom = $nom
    Initialize-VerifSnow 'homo'
    Submit-SnowRequete 'homo' $nom (Get-UrlJsonHomonymes $nom)
}

# Choix du CP demandé parmi les homonymes. Renvoie $true si un CP est retenu.
function Open-ChoixHomonyme {
    $choix = Show-HomonymesDialog $global:HomoComptes $txtNomPrenom.Text.Trim() $global:HomoCpDemande
    if (-not $choix) { return [bool]$global:HomoCpDemande }
    if ($choix.Action -eq 'ignore') {
        $global:HomoIgnore = ConvertTo-NomNormalise $txtNomPrenom.Text
        Set-ModeHomonyme $false
        Set-StatutHomo 'ignore' "Homonymes écartés ($(@($global:HomoComptes).Count) comptes) — cliquer pour revoir"
        return $false
    }
    $global:HomoCpDemande = $choix.CpDemande
    Update-StatutHomonyme
    $rtbCopy.Text = Get-CopyBlockText
    Update-Preview
    return $true
}

# ---- Doublons de demande ----

# Clé de la vérification doublons : RITM traitée + nom ($null si incomplet).
function Get-CleDoublon {
    $nom = $txtNomPrenom.Text.Trim()
    $ritm = ConvertTo-NumeroRitm $txtRITM.Text
    if (-not (Get-RequeteDoublons $nom) -or $ritm -notmatch '^RITM\d+$') { return $null }
    return "$ritm|$nom"
}
function Get-TexteAttenteDoublon {
    if (-not (Get-RequeteDoublons $txtNomPrenom.Text)) { return 'Saisir le nom et le prénom' }
    if ((ConvertTo-NumeroRitm $txtRITM.Text) -notmatch '^RITM\d+$') { return 'Saisir la RITM pour vérifier' }
    return 'Vérification à venir…'
}

# Pastille rouge : RITM citée dans le mail + rappel de la balise à poser.
function Update-StatutDoublonAlerte {
    $ritms = @(Get-RitmsDoublons $global:DoublonTaches)
    $r = if ($global:DoublonRitm) { $global:DoublonRitm } else { $ritms[0] }
    Set-StatutDoublon 'doublon' "⛔ DOUBLON : $r (cliquer)"
    $global:TipHomo.SetToolTip($lblDoublon, "Demande déjà en cours ou réalisée pour ce bénéficiaire : $($ritms -join ', ')`r`nRappel : passer la balise de la RITM à « Annulation - Doublon ».`r`nCliquer pour voir le détail.")
}

# Résultat ServiceNow : tâches d'arrivée ramenées pour la clé « RITM|nom ».
function Set-ResultatDoublons {
    param([string]$Cle, $Records)
    if ($Cle -ne (Get-CleDoublon)) { return }   # RITM ou nom modifié entre-temps
    $ritm, $nom = $Cle.Split('|', 2)
    $taches = @(Select-Doublons $Records $nom $ritm)
    $global:DoublonTaches = $taches
    $motifs = @(Get-MotifsRitmCourante $Records $nom $ritm)
    $motifTxt = if ($motifs.Count) { $motifs -join ' / ' } else { 'inconnu (tâche de la RITM traitée absente : toutes les demandes en cours retenues)' }
    Write-AppLog "[DOUBLON] $ritm : $(@($Records).Count) tâche(s) active(s) examinée(s), motif de référence : $motifTxt, $($taches.Count) doublon(s)."
    if ($taches.Count -gt 0) {
        $ritms = @(Get-RitmsDoublons $taches)
        Write-AppLog "[DOUBLON] $ritm : demande déjà existante ($($ritms -join ', ')) ; champ bénéficiaire reconnu : $(@($taches)[0].Champs)."
        if ($global:DoublonIgnore -eq $Cle) {
            Set-ModeDoublon $false
            Set-StatutDoublon 'ignore' "Doublon écarté ($($ritms -join ', ')) — cliquer pour revoir"
            return
        }
        $global:DoublonRitm = $ritms[0]   # la plus récente par défaut
        Set-ModeDoublon $true
        Update-StatutDoublonAlerte
    } else {
        Set-ModeDoublon $false
        Set-StatutDoublon 'ok' "✔ Pas de doublon de demande"
    }
}

# Lance (ou relance avec -Force) la vérification des doublons (RITM + nom requis :
# la RITM traitée a elle-même ses tâches dans la liste, elle doit être écartée).
function Invoke-VerifDoublons {
    param([switch]$Force)
    $cle = Get-CleDoublon
    if (-not $cle) {
        $global:DoublonDerniereCle = $null
        $global:DoublonTaches = @()
        Set-ModeDoublon $false
        Set-StatutDoublon 'idle' (Get-TexteAttenteDoublon)
        return
    }
    if (-not $Force -and $cle -eq $global:DoublonDerniereCle) { return }
    $global:DoublonDerniereCle = $cle
    Initialize-VerifSnow 'doublon'
    Submit-SnowRequete 'doublon' $cle (Get-UrlJsonDoublons ($cle.Split('|', 2)[1]))
}

# Choix de la RITM à citer. Renvoie $true si une RITM est retenue.
function Open-ChoixDoublon {
    $choix = Show-DoublonsDialog $global:DoublonTaches $txtNomPrenom.Text.Trim() (ConvertTo-NumeroRitm $txtRITM.Text) $global:DoublonRitm
    if (-not $choix) { return [bool]$global:DoublonRitm }
    if ($choix.Action -eq 'ignore') {
        $global:DoublonIgnore = $global:DoublonDerniereCle
        Set-ModeDoublon $false
        Set-StatutDoublon 'ignore' "Doublon écarté ($((Get-RitmsDoublons $global:DoublonTaches) -join ', ')) — cliquer pour revoir"
        return $false
    }
    $global:DoublonRitm = $choix.Ritm
    Update-StatutDoublonAlerte
    $rtbCopy.Text = Get-CopyBlockText
    Update-Preview
    return $true
}

# ---- Déclenchement ----

# Saisie du nom ou de la RITM : vérifications différées (~1,2 s après la dernière frappe).
$timerHomo = New-Object Windows.Forms.Timer
$timerHomo.Interval = 1200
$timerHomo.Add_Tick({
    $timerHomo.Stop()
    try { Invoke-VerifHomonymes } catch { Write-AppLog "[HOMO] Vérification KO : $($_.Exception.Message)"; Set-StatutHomo 'erreur' 'Vérification impossible (cliquer pour relancer)' }
    try { Invoke-VerifDoublons } catch { Write-AppLog "[DOUBLON] Vérification KO : $($_.Exception.Message)"; Set-StatutDoublon 'erreur' 'Vérification impossible (cliquer pour relancer)' }
}.GetNewClosure())
$txtNomPrenom.Add_TextChanged({
    # Le nom change : les alertes précédentes ne s'appliquent plus.
    if ($global:HomoActif) { Set-ModeHomonyme $false }
    if ($global:DoublonActif) { Set-ModeDoublon $false }
    if ($txtNomPrenom.Text.Trim() -ne $global:HomoDernierNom) {
        $global:HomoCpDemande = $null
        if ($global:HomoEtat -ne 'auth') { Set-StatutHomo 'idle' $(if (Get-RequeteHomonymes $txtNomPrenom.Text) { 'Vérification à venir…' } else { 'Saisir le nom et le prénom' }) }
    }
    if ($global:DoublonEtat -ne 'auth' -and (Get-CleDoublon) -ne $global:DoublonDerniereCle) { Set-StatutDoublon 'idle' (Get-TexteAttenteDoublon) }
    $timerHomo.Stop(); $timerHomo.Start()
}.GetNewClosure())
$txtRITM.Add_TextChanged({
    if ((Get-CleDoublon) -ne $global:DoublonDerniereCle) {
        if ($global:DoublonActif) { Set-ModeDoublon $false }
        if ($global:DoublonEtat -ne 'auth') { Set-StatutDoublon 'idle' (Get-TexteAttenteDoublon) }
    }
    $timerHomo.Stop(); $timerHomo.Start()
}.GetNewClosure())

$btnVerifHomo.Add_Click({
    try { Invoke-VerifHomonymes -Force } catch { Write-AppLog "[HOMO] Vérification KO : $($_.Exception.Message)"; Set-StatutHomo 'erreur' 'Vérification impossible (cliquer pour relancer)' }
})
$lblHomo.Add_Click({
    switch ($global:HomoEtat) {
        'homonyme' { [void](Open-ChoixHomonyme) }
        'ignore'   { $global:HomoIgnore = $null; Set-ModeHomonyme $true; Update-StatutHomonyme; [void](Open-ChoixHomonyme) }
        'erreur'   { Invoke-VerifHomonymes -Force }
        'auth'     { Show-SnowAuth }
    }
})
$btnVerifDoublon.Add_Click({
    try { Invoke-VerifDoublons -Force } catch { Write-AppLog "[DOUBLON] Vérification KO : $($_.Exception.Message)"; Set-StatutDoublon 'erreur' 'Vérification impossible (cliquer pour relancer)' }
})
$lblDoublon.Add_Click({
    switch ($global:DoublonEtat) {
        'doublon' { [void](Open-ChoixDoublon) }
        'ignore'  {
            $global:DoublonIgnore = $null
            Set-ModeDoublon $true
            $global:DoublonRitm = @(Get-RitmsDoublons $global:DoublonTaches)[0]
            Update-StatutDoublonAlerte
            [void](Open-ChoixDoublon)
        }
        'erreur'  { Invoke-VerifDoublons -Force }
        'auth'    { Show-SnowAuth }
    }
})
Set-StatutHomo 'idle' 'Saisir le nom et le prénom'
Set-StatutDoublon 'idle' 'Saisir le nom et le prénom'

# --- Événements ---
$btnGenPwd.Add_Click({
    if (-not (Test-NomPrenomValide $txtNomPrenom.Text)) {
        Show-AlertDialog -message "Saisissez d'abord le nom et le prénom du collaborateur (lettres, espaces, apostrophes et tirets uniquement)." -title "Nom et prénom"
        return
    }
    Remove-FichiersMotDePasse   # fichiers d'une génération précédente
    $pw = Generate-Password
    $txtPwd.Text = $pw
    Copy-MotDePasseSecurise $pw
    Show-AlertDialog -message "Le mot de passe a été généré et copié dans le presse-papiers.`n`nPar sécurité, il n'apparaît pas dans l'historique du presse-papiers (Win+V) et en sera effacé dans 2 minutes." -title "Mot de passe généré"
    $nomFichier = ($txtNomPrenom.Text -replace '\s', '')
    $global:CheminFichierTxt = Creer-FichierMotDePasse $pw $nomFichier
    $global:CheminZip = Creer-Zip $global:CheminFichierTxt $nomFichier
    Update-Preview
    $btnGenMsg.Enabled = $true
})

$btnGenMsg.Add_Click({
    # Pendant toute la génération (création du .msg, ouverture dans Outlook,
    # dialogues, saisie bénéficiaire), on suspend le masquage automatique :
    # l'utilisateur a encore des actions sur l'app après l'ouverture du message.
    $global:SuppressAutoHide = $true
    try {
    $ritm = $txtRITM.Text.Trim(); $nomPrenom = $txtNomPrenom.Text.Trim(); $dest = $txtEmail.Text.Trim()
    if ($ritm -eq "" -or $nomPrenom -eq "" -or $dest -eq "") {
        Show-AlertDialog -message "Remplissez tous les champs !" -title "Erreur"
        return
    }
    # Contrôle des saisies (elles finissent dans le mail, l'objet et les noms de fichiers).
    if (-not (Test-NumeroRitmValide $ritm)) {
        Show-AlertDialog -message "Le numéro de RITM « $ritm » n'est pas valide (attendu : RITM suivi de 7 à 10 chiffres)." -title "RITM"
        return
    }
    if (-not (Test-NomPrenomValide $nomPrenom)) {
        Show-AlertDialog -message "Le nom et prénom contient des caractères non autorisés (seuls les lettres, espaces, apostrophes, points et tirets sont acceptés)." -title "Nom et prénom"
        return
    }
    if (-not (Test-AdresseMailValide $dest)) {
        Show-AlertDialog -message "L'adresse du demandeur « $dest » n'est pas valide (une seule adresse électronique attendue)." -title "Email du demandeur"
        return
    }

    if ($global:ModeDoublon) {
        # --- Mode : doublon de demande -> mail d'annulation au demandeur, sans PJ ---
        # Pas de mot de passe, pas de vérification Mon-AD / OU, pas de saisie bénéficiaire.
        if (-not $global:DoublonRitm) {
            if (-not (Open-ChoixDoublon)) { return }
        }
        $objet = "$ritm - Annulation doublon $nomPrenom"
        $htmlFinal = Get-CorpsMessageHTML_Doublon_Final $global:DoublonRitm $cheminHeader $cheminSignature
        $webBrowser.DocumentText = Get-CorpsMessageHTML_Doublon_Preview $objet $global:DoublonRitm $cheminHeader $cheminSignature
        $cheminMsg = Join-Path $workDir "$ritm`_notif.msg"
        if (Creer-FichierMsg $objet $dest $htmlFinal "" $cheminMsg) {
            Write-AppLog "[DOUBLON] Mail d'annulation créé pour $ritm (doublon de $($global:DoublonRitm))."
            $rappelMsg = "Fichier .msg créé avec succès :`n$cheminMsg`n`nOuvrir le fichier maintenant ?"
            $resultatRappel = Show-AlertDialog -message $rappelMsg -title "MESSAGE CRÉÉ" -withCancel -buttonYesText "Ouvrir le fichier" -buttonNoText "Plus tard"
            if ($resultatRappel -eq [Windows.Forms.DialogResult]::Yes) {
                Invoke-Item -LiteralPath $cheminMsg
                Attendre-FermetureOutlookEtSupprimer $cheminMsg
            }
        }
        $rtbCopy.Text = Get-CopyBlockText
        Show-AlertDialog -message "N'oubliez pas de changer la balise de $ritm dans ServiceNow :`n`n        Annulation - Doublon`n`n(demande en doublon de $($global:DoublonRitm))." -title "RAPPEL : BALISE DE LA RITM"
        return
    }

    if ($global:ModeHomonyme) {
        # --- Mode : homonymes détectés -> mail au demandeur, sans PJ ---
        # Pas de mot de passe, pas de vérification Mon-AD / OU, pas de saisie bénéficiaire.
        if (-not $global:HomoCpDemande) {
            if (-not (Open-ChoixHomonyme)) { return }
        }
        $cpTrouves = (Get-CpTrouves $global:HomoComptes $global:HomoCpDemande) -join ', '
        $objet = "$ritm - Vérification homonyme $nomPrenom"
        $htmlFinal = Get-CorpsMessageHTML_Homonyme_Final $nomPrenom $global:HomoCpDemande $cpTrouves $cheminHeader $cheminSignature
        $webBrowser.DocumentText = Get-CorpsMessageHTML_Homonyme_Preview $objet $nomPrenom $global:HomoCpDemande $cpTrouves $cheminHeader $cheminSignature
        $cheminMsg = Join-Path $workDir "$ritm`_notif.msg"
        if (Creer-FichierMsg $objet $dest $htmlFinal "" $cheminMsg) {
            Write-AppLog "[HOMO] Mail homonyme créé pour $ritm."
            $rappelMsg = "Fichier .msg créé avec succès :`n$cheminMsg`n`nOuvrir le fichier maintenant ?"
            $resultatRappel = Show-AlertDialog -message $rappelMsg -title "MESSAGE CRÉÉ" -withCancel -buttonYesText "Ouvrir le fichier" -buttonNoText "Plus tard"
            if ($resultatRappel -eq [Windows.Forms.DialogResult]::Yes) {
                Invoke-Item -LiteralPath $cheminMsg
                Attendre-FermetureOutlookEtSupprimer $cheminMsg
            }
        }
        $rtbCopy.Text = Get-CopyBlockText
        return
    }

    if ($chkMdpDejaInit.Checked) {
        # --- Mode : mot de passe déjà initialisé ---
        # Date envoyée = déduite des jours restants avant expiration (valeur lue dans Mon-AD).
        $dateInit = Get-DateInitSaisie
        if (-not $dateInit) {
            Show-AlertDialog -message "Indiquez le nombre de jours restants avant expiration du mot de passe, tel qu'affiché dans Mon-AD (nombre entier de 0 à $script:DureeValiditeMdp)." -title "Erreur"
            return
        }
        $objet = "$ritm - Mot de passe déjà initialisé $nomPrenom"
        $htmlFinal = Get-CorpsMessageHTML_DejaInit_Final $nomPrenom $dateInit $cheminHeader $cheminSignature
        $htmlPreview = Get-CorpsMessageHTML_DejaInit_Preview $objet $nomPrenom $dateInit $cheminHeader $cheminSignature
        $webBrowser.DocumentText = $htmlPreview
        $cheminMsg = Join-Path $workDir "$ritm`_notif.msg"
        if (Creer-FichierMsg $objet $dest $htmlFinal "" $cheminMsg) {
            $rappelMsg = "Fichier .msg créé avec succès :`n$cheminMsg`n`nOuvrir le fichier maintenant ?"
            $resultatRappel = Show-AlertDialog -message $rappelMsg -title "MESSAGE CRÉÉ" -withCancel -buttonYesText "Ouvrir le fichier" -buttonNoText "Plus tard"
            if ($resultatRappel -eq [Windows.Forms.DialogResult]::Yes) {
                Invoke-Item -LiteralPath $cheminMsg
                Attendre-FermetureOutlookEtSupprimer $cheminMsg
            }
        }
        # Demander les informations du bénéficiaire
        $global:CopyDateInit = $dateInit
        $benef = Show-BeneficiaireDialog
        if ($benef) {
            if ($benef.Email) { $global:CopyEmailBenef = $benef.Email }
            if ($benef.OU) { $global:CopyOU = ($benef.OU -replace '\s+', '/') -replace '/+', '/' }
        }
        $rtbCopy.Text = Get-CopyBlockText
    } else {
        # --- Mode : nouveau mot de passe ---
        $actionsVerif = Show-AlertDialog -message "Avez-vous bien :`n- Modifié le mot de passe dans Mon-AD`n- Déplacé le compte dans la bonne OU`n`nSi ces actions n'ont pas été réalisées, cliquez sur NON." -title "VÉRIFICATION DES ACTIONS" -withCancel -buttonYesText "Oui, tout est fait" -buttonNoText "Non, abandonner"
        if ($actionsVerif -eq [Windows.Forms.DialogResult]::No) {
            Show-AlertDialog -message "Opération annulée. Veuillez réaliser les actions nécessaires avant de générer le message." -title "Opération annulée"
            return
        }
        if (-not $global:CheminZip -or -not (Test-Path -LiteralPath $global:CheminZip)) {
            Show-AlertDialog -message "Générez le mot de passe d'abord." -title "Erreur"
            return
        }
        $objet = "$ritm - Notification mot de passe $nomPrenom"
        $htmlFinal = Get-CorpsMessageHTML_Final $nomPrenom $cheminHeader $cheminSignature
        $htmlPreview = Get-CorpsMessageHTML_Preview $objet $nomPrenom $cheminHeader $cheminSignature
        $webBrowser.DocumentText = $htmlPreview
        $cheminMsg = Join-Path $workDir "$ritm`_notif.msg"
        if (Creer-FichierMsg $objet $dest $htmlFinal $global:CheminZip $cheminMsg) {
            # Le .msg embarque la pièce jointe : le .txt et le .zip en clair ne servent
            # plus, ils sont supprimés systématiquement.
            Remove-FichiersMotDePasse
            $rappelMsg = "Fichier .msg créé avec succès :`n$cheminMsg`n`nOuvrir le fichier maintenant ?"
            $resultatRappel = Show-AlertDialog -message $rappelMsg -title "MESSAGE CRÉÉ" -withCancel -buttonYesText "Ouvrir le fichier" -buttonNoText "Plus tard"
            if ($resultatRappel -eq [Windows.Forms.DialogResult]::Yes) {
                Invoke-Item -LiteralPath $cheminMsg
                Attendre-FermetureOutlookEtSupprimer $cheminMsg
            }
        }
        # Demander les informations du bénéficiaire
        $benef = Show-BeneficiaireDialog
        if ($benef) {
            if ($benef.Email) { $global:CopyEmailBenef = $benef.Email }
            if ($benef.OU) { $global:CopyOU = ($benef.OU -replace '\s+', '/') -replace '/+', '/' }
            $rtbCopy.Text = Get-CopyBlockText
        }
    }
    } finally {
        $global:SuppressAutoHide = $false
    }
})

foreach ($c in @($txtRITM, $txtNomPrenom, $txtEmail)) {
    $c.Add_TextChanged({Update-Preview})
}

Update-Preview

# --- Mise à jour : « Quoi de neuf » après une montée, puis vérification périodique ---
$global:Ctx.UpdateAvailable = $null
$form.Add_Shown({
    try { Show-WhatsNewIfUpgraded $global:Ctx $global:PrevStateVersion } catch { Write-AppLog "[VERSION] Quoi de neuf KO : $($_.Exception.Message)" }
    # 1er contrôle ~8 s après ouverture, puis selon Config.UpdateCheckIntervalSec.
    $timerUpd = New-Object Windows.Forms.Timer
    $timerUpd.Interval = 8000
    $timerUpd.Add_Tick({
        $this.Interval = [Math]::Max(10, [int]$global:Ctx.Config.UpdateCheckIntervalSec) * 1000
        try { Start-UpdateCheckAsync $global:Ctx } catch { Write-AppLog "[MAJ] Tick KO : $($_.Exception.Message)" }
    })
    $timerUpd.Start()
    # Tutoriel au tout premier lancement (différé ~1,4 s pour laisser l'UI se peindre).
    $timerTuto = New-Object Windows.Forms.Timer
    $timerTuto.Interval = 1400
    $timerTuto.Add_Tick({
        $this.Stop()
        try { Show-TutorialIfFirstRun $global:Ctx } catch { Write-AppLog "[TUTO] 1er lancement KO : $($_.Exception.Message)" }
    })
    $timerTuto.Start()
})

# ============================================================================
#  Masquage de l'app : un bouton « masquer » (en-tête) fait coulisser la fenêtre
#  hors écran vers la droite, puis affiche une petite LANGUETTE au bord droit de
#  l'écran de l'app. Clic sur la languette : l'app revient en glissant. La languette
#  n'apparaît QUE pendant le masquage. Tout est recalculé au clic (correct multi-écran).
# ============================================================================
$global:AppHidden = $false
# Drapeau : suspend le masquage automatique pendant le flux de génération du .msg.
$global:SuppressAutoHide = $false
# Préférence UTILISATEUR : ne pas replier en bulle à la perte de focus (la fenêtre
# reste visible sur le côté). Basculable par clic droit sur « » » ou sur la bulle ;
# persistée dans state.json. Le masquage MANUEL (clic sur « » ») reste possible.
$global:AutoHideDisabled = [bool]$global:Ctx.State.AutoHideDisabled
# Dernière position de la bulle ($null = jamais déplacée => position par défaut).
$global:BubbleLastPos = $null
# Position d'apparition résolue au masquage + bounds pleins de l'app (pour l'animation).
$global:BubbleNextPos = $null
$global:BubbleSide = 'Right'
$global:AppFullBounds = $null
# Capture de la fenêtre (image source du fantôme animé).
$global:GhostSrc = $null

# Bouton « masquer » dans l'en-tête (à gauche du bouton « ? »).
$btnHide = New-Object Windows.Forms.Button
$btnHide.Text = "»"
$btnHide.Size = New-Object Drawing.Size(34, 34)
$btnHide.Location = New-Object Drawing.Point(1002, 18)
$btnHide.FlatStyle = 'Flat'; $btnHide.FlatAppearance.BorderSize = 0
$btnHide.FlatAppearance.MouseOverBackColor = $cAccentVioletHover
$btnHide.BackColor = $cBorder; $btnHide.ForeColor = $cWhite
$btnHide.Font = [Drawing.Font]::new("Segoe UI", 12, [Drawing.FontStyle]::Bold)
$btnHide.Cursor = [Windows.Forms.Cursors]::Hand
$btnHide.Anchor = [Windows.Forms.AnchorStyles]::Top -bor [Windows.Forms.AnchorStyles]::Right
$form.Controls.Add($btnHide)
$btnHide.BringToFront()

# Bulle RONDE flottante (style « bulle de discussion ») avec l'icône de l'app. Cachée
# par défaut ; n'apparaît qu'une fois l'app masquée.
$bubble = New-Object Windows.Forms.Form
$bubble.FormBorderStyle = 'None'; $bubble.ShowInTaskbar = $false
$bubble.StartPosition = 'Manual'; $bubble.TopMost = $true
# Windows impose une largeur mini de fenêtre (~136 px) : sans lever cette contrainte,
# la bulle resterait large de 136 px (cercle clippé à gauche => bulle « décalée »).
$bubble.MinimumSize = New-Object Drawing.Size(1, 1)
$bubble.AutoScaleMode = 'None'
$bubble.Size = New-Object Drawing.Size(54, 54)
$bubble.BackColor = [Drawing.Color]::White
$bpath = New-Object Drawing.Drawing2D.GraphicsPath
$bpath.AddEllipse(0, 0, 54, 54)
$bubble.Region = New-Object Drawing.Region($bpath)
$bubble.Cursor = [Windows.Forms.Cursors]::Hand

$picBubble = New-Object Windows.Forms.PictureBox
$picBubble.Dock = 'Fill'; $picBubble.SizeMode = 'StretchImage'
$picBubble.BackColor = [Drawing.Color]::White
$picBubble.Cursor = [Windows.Forms.Cursors]::Hand
# Avatar = SEULEMENT la TÊTE de la conseillère, recadrée depuis l'en-tête paysage
# (qui contient aussi un robot et le buste). Rect calé sur le visage détecté (35,14,80,80).
try {
    if (Test-Path $cheminHeader) {
        $srcAvatar = New-Object Drawing.Bitmap($cheminHeader)
        $crop = New-Object Drawing.Rectangle(35, 14, 80, 80)
        $picBubble.Image = $srcAvatar.Clone($crop, $srcAvatar.PixelFormat)
        $srcAvatar.Dispose()
    } elseif ($picHeader.Image) { $picBubble.Image = $picHeader.Image }
} catch { if ($picHeader.Image) { $picBubble.Image = $picHeader.Image } }
$bubble.Controls.Add($picBubble)

# --- Déplacement de la bulle à la souris (comme les bulles de discussion Messenger) ---
# On distingue un simple clic (=> afficher l'app) d'un glisser (=> repositionner la bulle).
# Un glisser au-delà de 5 px verrouille le mode déplacement ; au relâchement la bulle
# s'aimante au bord gauche/droit le plus proche de l'écran où elle se trouve.
$dragState = @{ Dragging = $false; Moved = $false; OffX = 0; OffY = 0; DownX = 0; DownY = 0 }
$picBubble.Add_MouseDown({
    param($s, $e)
    if ($e.Button -ne [Windows.Forms.MouseButtons]::Left) { return }
    $dragState.Dragging = $true
    $dragState.Moved = $false
    $dragState.OffX = $e.X
    $dragState.OffY = $e.Y
    $p = [Windows.Forms.Cursor]::Position
    $dragState.DownX = $p.X; $dragState.DownY = $p.Y
})
$picBubble.Add_MouseMove({
    param($s, $e)
    if (-not $dragState.Dragging) { return }
    $p = [Windows.Forms.Cursor]::Position
    if (-not $dragState.Moved -and ([Math]::Abs($p.X - $dragState.DownX) -gt 5 -or [Math]::Abs($p.Y - $dragState.DownY) -gt 5)) {
        $dragState.Moved = $true
    }
    $bubble.Location = New-Object Drawing.Point(($p.X - $dragState.OffX), ($p.Y - $dragState.OffY))
})
$picBubble.Add_MouseUp({
    param($s, $e)
    if ($e.Button -ne [Windows.Forms.MouseButtons]::Left) { return }
    if (-not $dragState.Dragging) { return }
    $dragState.Dragging = $false
    if ($dragState.Moved) {
        # Aimantation au bord gauche/droit le plus proche de l'écran courant.
        $cx = $bubble.Left + [int]($bubble.Width / 2)
        $cy = $bubble.Top + [int]($bubble.Height / 2)
        $wa = [Windows.Forms.Screen]::FromPoint((New-Object Drawing.Point($cx, $cy))).WorkingArea
        $y = [Math]::Max($wa.Top, [Math]::Min($bubble.Top, $wa.Bottom - $bubble.Height))
        if ($cx -lt ($wa.Left + $wa.Width / 2)) { $x = $wa.Left + 8; $global:BubbleSide = 'Left' } else { $x = $wa.Right - $bubble.Width - 8; $global:BubbleSide = 'Right' }
        $bubble.Location = New-Object Drawing.Point([int]$x, [int]$y)
        # Mémorise la position + le côté pour la prochaine animation et le prochain masquage.
        $global:BubbleLastPos = $bubble.Location
    } else {
        Show-App
    }
})

# ============================================================================
#  Animation de masquage/affichage : au masquage, une IMAGE FANTÔME de l'app
#  rétrécit en ligne droite vers la bulle en s'estompant ; à l'affichage, elle
#  ré-émerge de la bulle et grandit jusqu'à sa position. Effet volontairement
#  MINIMAL (zoom + fondu, sans rotation/spirale/flou : trop coûteux par frame,
#  l'animation saccadait). Point focal = la bulle (pas le bord d'écran) =>
#  robuste multi-écran ; le vrai formulaire n'est jamais redimensionné.
#  Fenêtre à transparence PAR PIXEL (UpdateLayeredWindow).
# ============================================================================
# Fenêtre à transparence PAR PIXEL (alpha doux, pas de bord net) via UpdateLayeredWindow.
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class LayeredGhost {
    [DllImport("user32.dll", SetLastError=true)] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll", SetLastError=true)] static extern int SetWindowLong(IntPtr h, int i, int v);
    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h, IntPtr dc);
    [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr dc);
    [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr dc, IntPtr o);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr o);
    [DllImport("user32.dll", SetLastError=true)]
    static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr dst, ref POINT pDst, ref SIZE size, IntPtr src, ref POINT pSrc, int key, ref BLENDFUNCTION bf, int flags);
    [StructLayout(LayoutKind.Sequential)] struct POINT { public int x, y; public POINT(int a, int b){x=a;y=b;} }
    [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; public SIZE(int a, int b){cx=a;cy=b;} }
    [StructLayout(LayoutKind.Sequential, Pack=1)] struct BLENDFUNCTION { public byte Op, Flags, Alpha, Format; }
    const int GWL_EXSTYLE=-20, WS_EX_LAYERED=0x80000, ULW_ALPHA=2;
    public static void Enable(IntPtr hwnd) {
        int ex = GetWindowLong(hwnd, GWL_EXSTYLE);
        SetWindowLong(hwnd, GWL_EXSTYLE, ex | WS_EX_LAYERED);
    }
    // NB : pas de prémultiplication alpha — les frames sont entièrement opaques
    // (alpha par pixel = 255, où prémultiplié == direct) ; le fondu passe par
    // BLENDFUNCTION.Alpha. Évite une boucle managée sur tous les pixels par frame.
    public static void Update(IntPtr hwnd, Bitmap bmp, int x, int y, byte alpha) {
        IntPtr screen = GetDC(IntPtr.Zero);
        IntPtr mem = CreateCompatibleDC(screen);
        IntPtr hb = IntPtr.Zero, old = IntPtr.Zero;
        try {
            hb = bmp.GetHbitmap(Color.FromArgb(0));
            old = SelectObject(mem, hb);
            SIZE sz = new SIZE(bmp.Width, bmp.Height);
            POINT ps = new POINT(0,0); POINT pd = new POINT(x,y);
            BLENDFUNCTION bf = new BLENDFUNCTION(); bf.Op=0; bf.Flags=0; bf.Alpha=alpha; bf.Format=1;
            UpdateLayeredWindow(hwnd, screen, ref pd, ref sz, mem, ref ps, 0, ref bf, ULW_ALPHA);
        } finally {
            if (old != IntPtr.Zero) SelectObject(mem, old);
            if (hb != IntPtr.Zero) DeleteObject(hb);
            DeleteDC(mem); ReleaseDC(IntPtr.Zero, screen);
        }
    }
}
"@

# P/Invoke : fenêtre au premier plan + son PID (pour le masquage automatique).
Add-Type -Namespace Win32 -Name Fg -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern System.IntPtr GetForegroundWindow();
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern uint GetWindowThreadProcessId(System.IntPtr hWnd, out uint lpdwProcessId);
'@

$ghost = New-Object Windows.Forms.Form
$ghost.FormBorderStyle = 'None'; $ghost.ShowInTaskbar = $false
$ghost.StartPosition = 'Manual'; $ghost.TopMost = $true
$ghost.MinimumSize = New-Object Drawing.Size(1, 1)
$ghost.AutoScaleMode = 'None'
$null = $ghost.Handle                       # force la création du handle
[LayeredGhost]::Enable($ghost.Handle)       # active la transparence par pixel

# Capture pixel-fidèle de la fenêtre (inclut le WebBrowser d'aperçu) -> $global:GhostSrc.
function Capture-FormToGhost {
    try {
        $b = $form.Bounds
        $bmp = New-Object Drawing.Bitmap($b.Width, $b.Height)
        $g = [Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen($b.X, $b.Y, 0, 0, $b.Size)
        $g.Dispose()
        $old = $global:GhostSrc; $global:GhostSrc = $bmp; if ($old) { $old.Dispose() }
    } catch { $global:GhostSrc = $null }
}

# Compose + affiche une frame : capture de l'app redimensionnée ($Dw x $Dh),
# centrée sur ($Cx,$Cy), avec fondu $Alpha (0-255). Un seul DrawImage bilinéaire
# par frame pour rester fluide (le fondu passe par l'alpha de la fenêtre).
function Set-GhostFrame($Cx, $Cy, $Dw, $Dh, $Alpha) {
    $w = [int][Math]::Max(1, $Dw); $h = [int][Math]::Max(1, $Dh)
    $bmp = New-Object Drawing.Bitmap($w, $h, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = 'Bilinear'
    $g.DrawImage($global:GhostSrc, (New-Object Drawing.Rectangle(0, 0, $w, $h)))
    $g.Dispose()
    $x = [int]($Cx - $w / 2.0); $y = [int]($Cy - $h / 2.0)
    $a = [int]$Alpha; if ($a -lt 0) { $a = 0 } elseif ($a -gt 255) { $a = 255 }
    [LayeredGhost]::Update($ghost.Handle, $bmp, $x, $y, [byte]$a)
    $bmp.Dispose()
}

$slideTimer = New-Object Windows.Forms.Timer
$slideTimer.Interval = 10
$slideState = @{ Frame = 0; Total = 14; Hiding = $false
    AppCx = 0.0; AppCy = 0.0; BubCx = 0.0; BubCy = 0.0; W0 = 1; H0 = 1 }
$slideTimer.Add_Tick({
    $slideState.Frame++
    $t = $slideState.Frame / $slideState.Total
    if ($t -gt 1) { $t = 1 }
    if ($slideState.Hiding) {
        $p = [Math]::Pow($t, 1.9)                       # rétractation : retient puis happe
    } else {
        $p = 1.0 - [Math]::Pow(1 - $t, 1.9)             # apparition : jaillit puis se pose
    }
    # 'a' = proximité de la bulle (0 = pleine app, 1 = réduite dans la bulle).
    $a = if ($slideState.Hiding) { $p } else { 1.0 - $p }
    $scale = 1.0 - 0.96 * $a
    $alpha = 255.0 * (1.0 - 0.85 * $a)
    if ($slideState.Hiding) {
        $cx = $slideState.AppCx + ($slideState.BubCx - $slideState.AppCx) * $p
        $cy = $slideState.AppCy + ($slideState.BubCy - $slideState.AppCy) * $p
    } else {
        $cx = $slideState.BubCx + ($slideState.AppCx - $slideState.BubCx) * $p
        $cy = $slideState.BubCy + ($slideState.AppCy - $slideState.BubCy) * $p
    }
    Set-GhostFrame $cx $cy ($slideState.W0 * $scale) ($slideState.H0 * $scale) $alpha
    if ($slideState.Frame -ge $slideState.Total) {
        $slideTimer.Stop()
        if ($slideState.Hiding) {
            $global:AppHidden = $true
            $bubble.Location = $global:BubbleNextPos
            $global:BubbleLastPos = $global:BubbleNextPos
            $bubble.TopMost = $true
            $bubble.Show(); $bubble.BringToFront()
            $ghost.Hide()
            $bubble.Activate()
        } else {
            $form.Bounds = $global:AppFullBounds
            $form.Show(); $form.Activate()
            $global:AppHidden = $false
            $ghost.Hide()
        }
    }
}.GetNewClosure())

function Hide-App {
    if ($slideTimer.Enabled -or $global:AppHidden) { return }
    # Résout la position d'apparition de la bulle (mémorisée, sinon défaut bord droit).
    $bw = $bubble.Width; $bh = $bubble.Height
    $pos = $global:BubbleLastPos; $valid = $false
    if ($null -ne $pos) {
        $vc = New-Object Drawing.Point(($pos.X + [int]($bw / 2)), ($pos.Y + [int]($bh / 2)))
        if ([Windows.Forms.SystemInformation]::VirtualScreen.Contains($vc)) { $valid = $true }
    }
    if (-not $valid) {
        $wa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $pos = New-Object Drawing.Point(($wa.Right - $bw - 8), [int]($wa.Top + ($wa.Height - $bh) / 2))
    }
    $global:BubbleNextPos = $pos
    $global:AppFullBounds = $form.Bounds
    Capture-FormToGhost
    $fb = $global:AppFullBounds
    if ($null -eq $global:GhostSrc) {
        # Repli si la capture a échoué : masquage direct sans animation.
        $global:AppHidden = $true; $form.Hide()
        $bubble.Location = $pos; $global:BubbleLastPos = $pos
        $bubble.TopMost = $true; $bubble.Show(); $bubble.BringToFront(); return
    }
    $slideState.W0 = $fb.Width; $slideState.H0 = $fb.Height
    $slideState.AppCx = $fb.X + $fb.Width / 2.0; $slideState.AppCy = $fb.Y + $fb.Height / 2.0
    $slideState.BubCx = $pos.X + $bw / 2.0; $slideState.BubCy = $pos.Y + $bh / 2.0
    $slideState.Frame = 0; $slideState.Hiding = $true
    # Frame 0 = image pleine et nette => relais sans rupture avec la fenêtre.
    [LayeredGhost]::Enable($ghost.Handle)
    Set-GhostFrame $slideState.AppCx $slideState.AppCy $fb.Width $fb.Height 255
    $ghost.Visible = $true; $ghost.BringToFront()
    $form.Hide()
    $slideTimer.Start()
}
function Show-App {
    if (-not $global:AppHidden -or $slideTimer.Enabled) { return }
    if ($null -eq $global:GhostSrc -or $null -eq $global:AppFullBounds) {
        # Repli : affichage direct.
        $bubble.Hide(); if ($global:AppFullBounds) { $form.Bounds = $global:AppFullBounds }
        $form.Show(); $form.Activate(); $global:AppHidden = $false; return
    }
    $fb = $global:AppFullBounds
    $slideState.W0 = $fb.Width; $slideState.H0 = $fb.Height
    $slideState.AppCx = $fb.X + $fb.Width / 2.0; $slideState.AppCy = $fb.Y + $fb.Height / 2.0
    $slideState.BubCx = $bubble.Left + $bubble.Width / 2.0; $slideState.BubCy = $bubble.Top + $bubble.Height / 2.0
    $slideState.Frame = 0; $slideState.Hiding = $false
    # Frame 0 = tout petit et transparent, au centre de la bulle.
    [LayeredGhost]::Enable($ghost.Handle)
    Set-GhostFrame $slideState.BubCx $slideState.BubCy ($fb.Width * 0.04) ($fb.Height * 0.04) 40
    $bubble.Hide()
    $ghost.Visible = $true; $ghost.BringToFront()
    $slideTimer.Start()
}

$btnHide.Add_Click({ Hide-App })

# ============================================================================
#  Masquage AUTOMATIQUE : quand l'app perd le focus vers une AUTRE application,
#  elle se replie en bulle (même animation que le bouton « masquer »). Un timer
#  mono-coup de 200 ms laisse le nouveau premier plan se stabiliser ; on ne
#  masque que si sa fenêtre appartient à un autre processus (cf. Should-AutoHide,
#  lib/Common.ps1). Couvre ainsi dialogues, popup calendrier, tutoriel, bulle.
#  Désactivable via l'option « Réduction automatique en bulle » (clic droit sur
#  le bouton « » » ou sur la bulle) — voir Set-AutoHideDisabled plus bas.
# ============================================================================
$timerAutoHide = New-Object Windows.Forms.Timer
$timerAutoHide.Interval = 200
$timerAutoHide.Add_Tick({
    $timerAutoHide.Stop()
    $h = [Win32.Fg]::GetForegroundWindow()
    $fgPid = [uint32]0
    if ($h -ne [IntPtr]::Zero) { [void][Win32.Fg]::GetWindowThreadProcessId($h, [ref]$fgPid) }
    if (Should-AutoHide -AppHidden $global:AppHidden -Animating $slideTimer.Enabled -Suppressed $global:SuppressAutoHide -ForegroundPid ([int]$fgPid) -OwnPid $PID -Disabled $global:AutoHideDisabled) {
        Hide-App
    }
}.GetNewClosure())
$form.Add_Deactivate({
    if ($global:AppHidden -or $slideTimer.Enabled -or $global:SuppressAutoHide -or $global:AutoHideDisabled) { return }
    $timerAutoHide.Stop(); $timerAutoHide.Start()
}.GetNewClosure())
# (le clic simple sur la bulle est géré par MouseUp ci-dessus : tap = afficher, glisser = déplacer)

# Clic-DROIT sur la bulle : menu pour afficher ou fermer l'app même en mode masqué
# (sans ce menu, une app masquée n'a aucun moyen d'être fermée -> instances empilées).
$bubbleMenu = New-Object Windows.Forms.ContextMenuStrip
$bubbleMenu.BackColor = $cBgSecondary
$bubbleMenu.ForeColor = $cTextPrimary
$bubbleMenu.ShowImageMargin = $false
$miShow = $bubbleMenu.Items.Add("Afficher l'application")
$miShow.add_Click({ Show-App })
$miClose = $bubbleMenu.Items.Add("Fermer l'application")
$miClose.add_Click({ $global:AppHidden = $false; $bubble.Hide(); $form.Close() })
$bubble.ContextMenuStrip = $bubbleMenu
$picBubble.ContextMenuStrip = $bubbleMenu

# ============================================================================
#  Option « Réduction automatique en bulle » : certains collègues préfèrent garder
#  la fenêtre visible sur le côté en travaillant dans une autre application. Item
#  COCHABLE accessible par clic droit sur le bouton « » » ET sur la bulle ; décoché,
#  l'app ne se replie plus à la perte de focus (le repli manuel via « » » reste
#  possible). Préférence persistée dans state.json (auto_hide_disabled).
# ============================================================================
function Set-AutoHideDisabled([bool]$Disabled) {
    $global:AutoHideDisabled = $Disabled
    $global:Ctx.State.AutoHideDisabled = $Disabled
    # Reflète l'état sur la case à cocher du formulaire (assigner une valeur identique
    # ne re-déclenche pas CheckedChanged : pas de boucle).
    try { $chkAutoBulle.Checked = -not $Disabled } catch { }
    try { Save-AppState $global:Ctx.State } catch { }
}
$hideMenu = New-Object Windows.Forms.ContextMenuStrip
$hideMenu.BackColor = $cBgSecondary
$hideMenu.ForeColor = $cTextPrimary
$hideMenu.ShowImageMargin = $false
$hideMenu.ShowCheckMargin = $true
$miAutoHideBtn = $hideMenu.Items.Add("Réduction automatique en bulle")
$miAutoHideBtn.add_Click({ Set-AutoHideDisabled (-not $global:AutoHideDisabled) })
$hideMenu.add_Opening({ $miAutoHideBtn.Checked = -not $global:AutoHideDisabled }.GetNewClosure())
$btnHide.ContextMenuStrip = $hideMenu

$bubbleMenu.ShowCheckMargin = $true
[void]$bubbleMenu.Items.Add((New-Object Windows.Forms.ToolStripSeparator))
$miAutoHideBub = $bubbleMenu.Items.Add("Réduction automatique en bulle")
$miAutoHideBub.add_Click({ Set-AutoHideDisabled (-not $global:AutoHideDisabled) })
$bubbleMenu.add_Opening({ $miAutoHideBub.Checked = -not $global:AutoHideDisabled }.GetNewClosure())

$form.Add_FormClosed({ try { $bubble.Close() } catch { }; try { $ghost.Close() } catch { } })
# Fermeture : libère le WebView2 caché (et ses processus msedgewebview2).
# Dispose() plutôt que Close() : Close passerait par FormClosing qui re-cache la fenêtre.
$form.Add_FormClosed({
    try { Remove-FichiersMotDePasse } catch { }
    try { if ($global:Snow.Timer) { $global:Snow.Timer.Stop() } } catch { }
    try { if ($global:Snow.WebView) { $global:Snow.WebView.Dispose() } } catch { }
    try { if ($global:Snow.Form) { $global:Snow.Form.Dispose() } } catch { }
})

# Démarrage TOUJOURS centré sur l'écran principal — UNE SEULE fois (sinon le re-Show
# de la languette recentrerait l'app au lieu de la laisser glisser).
$global:AppFirstShown = $false
$form.Add_Shown({
    if ($global:AppFirstShown) { return }
    $global:AppFirstShown = $true
    try {
        $pa = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $x = [int]($pa.X + ($pa.Width - $form.Width) / 2)
        $y = [Math]::Max($pa.Y, [int]($pa.Y + ($pa.Height - $form.Height) / 2))
        $form.Location = New-Object Drawing.Point($x, $y)
    } catch { }
})

# Boucle principale : Application::Run (et non ShowDialog) pour que la languette
# reste active à côté de la fenêtre principale.
[Windows.Forms.Application]::Run($form)
